"""Finite-fragment engineering regression tests, not experimental model scores."""
import copy,json,sqlite3,tempfile,unittest
from pathlib import Path
from rdflib import Graph,RDF,OWL,URIRef
from ontoreason_core import *

ONTO='@prefix owl:<http://www.w3.org/2002/07/owl#>. <urn:Student> a owl:Class.'
M={'id':'student','query':'SELECT id FROM Student','heads':[[{'kind':'iri','template':'urn:student:{id}'},{'kind':'constant','value':str(RDF.type)},{'kind':'constant','value':'urn:Student'}]],'null_policy':'skip_statement','identity_policy':'stable source id'}

class CoreTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.db=self.root/'source.sqlite';c=sqlite3.connect(self.db);c.executescript('CREATE TABLE Student(id INTEGER PRIMARY KEY);INSERT INTO Student VALUES(1);');c.close()
  self.source=self.root/'business.txt';self.source.write_text('Approved independent business requirement.',encoding='utf-8')
  self.ob=Obligation('o','independent_fixture_checker','Requirement is independently witnessed',((str(self.source),file_sha(self.source)),),'fixture-authority','stable-id')
  self.assessor=Assessor({'independent_fixture_checker':lambda e,o:dict(status='SUPPORTED',reason='Fixture source checked')},{k:'fixture-v1' for k in ['checker','compiler','model','prompt','search_scope']})
  self.store=Store(self.root/'store')
 def tearDown(self):self.temp.cleanup()
 def event(self,name='e',requires=()):return Event(name,set(requires),[self.ob])
 def publish(self,parent=None,events=None,selection=None,**kwargs):
  events=events or {};a={k:self.assessor.assess(e) for k,e in events.items()}
  return self.store.publish(parent,ONTO,{'student':copy.deepcopy(M)},self.db,selection or {'selected':list(events)},events,a,kwargs.pop('reasoner',lambda g:True),assessor=self.assessor,**kwargs)
 def test_registered_impact_refines_unknown_boundary(self):
  r=Registry({'column':['mapping'],'mapping':['class'],'boundary':['consumer']},{'mapping':['boundary']});region,trace=r.refine(['column'],lambda n:'UNKNOWN');self.assertEqual(region,{'column','mapping','class','boundary','consumer'});self.assertEqual(len(trace),2)
 def test_unknown_prerequisite_blocks_scc_but_not_independent(self):
  a=self.event('class',['mapping']);b=self.event('mapping',['class']);c=self.event('relation',['class']);repair=self.event('repair')
  events={e.id:e for e in [a,b,c,repair]};assess={k:self.assessor.assess(e) for k,e in events.items()};assess['mapping']['status']='UNKNOWN';result=select(events,assess);self.assertEqual(result['selected'],['repair']);self.assertIn(['class','mapping'],result['groups'])
 def test_malformed_event_id_rejected(self):
  with self.assertRaises(ValueError):select({'wrong':self.event('right')},{})
 def test_unknown_and_stale_sources_do_not_pass(self):
  e=self.event();self.source.write_text('changed');self.assertEqual(self.assessor.assess(e)['status'],'UNKNOWN')
  with self.assertRaises(ValueError):self.publish(events={'e':e})
 def test_joint_publication_failure_keeps_parent(self):
  head=self.publish();e=self.event()
  with self.assertRaises(RuntimeError):self.publish(head,{'e':e},fail_before_head=True)
  self.assertEqual(self.store.head(),head);self.assertEqual(file_sha(head['snapshot']),head['snapshot_sha256'])
 def test_inherited_inventory_cannot_be_deleted(self):
  head=self.publish()
  with self.assertRaises(ValueError):self.store.publish(head,ONTO,{},self.db,{'selected':[]},{},{},lambda g:True)
 def test_conflicting_forged_selection_rejected(self):
  a,b=self.event('a'),self.event('b')
  with self.assertRaises(ValueError):self.publish(events={'a':a,'b':b},conflicts=[('a','b')])
 def test_snapshot_change_during_check_cannot_change_bound_state(self):
  def validator(g):
   c=sqlite3.connect(self.db);c.execute('INSERT INTO Student VALUES(2)');c.commit();c.close();return True
  with self.assertRaises(ValueError):self.publish(reasoner=validator)
  self.assertIsNone(self.store.head());self.assertEqual(len(query_rows(self.db,'SELECT id FROM Student')),2)
 def test_mapping_repair_requires_complete_results(self):
  head=self.publish();e=self.event();e.interpretation='REPAIR';e.mapping_updates={'student':dict(M,query='SELECT id FROM Student WHERE id=2')}
  with self.assertRaises(ValueError):self.publish(head,{'e':e})
 def test_fixed_head_repair_preserves_multiset_and_facts(self):
  new=dict(M,query='SELECT id FROM Student WHERE id IS NOT NULL');self.assertTrue(verify_repair(M,new,self.db,self.db)['preserved']);changed=copy.deepcopy(new);changed['heads'][0][0]['template']='urn:different:{id}';self.assertFalse(verify_repair(M,changed,self.db,self.db)['preserved'])
 def test_reasoner_receives_ontology_and_materialized_facts(self):
  def validator(g):self.assertIn((URIRef('urn:student:1'),RDF.type,URIRef('urn:Student')),g);return True
  self.publish(reasoner=validator)
 def test_unknown_consistency_blocks_publication(self):
  with self.assertRaises(ValueError):self.publish(reasoner=lambda g:None)
  self.assertIsNone(self.store.head())
 def test_sql_write_cannot_execute(self):
  with self.assertRaises(ValueError):query_rows(self.db,'DELETE FROM Student')

if __name__=='__main__':unittest.main()
