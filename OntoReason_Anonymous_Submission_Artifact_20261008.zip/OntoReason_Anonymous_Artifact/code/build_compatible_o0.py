"""Source-physical additive O0 compatibility preflight, no API or gold reads."""
import argparse,copy,importlib.util,json,os,sqlite3,sys
from pathlib import Path
R=Path(__file__).resolve().parent;sys.path[:0]=[str(R/'packages_minimal'),str(R/'dynamic'),str(R/'evaluation')]
from rdflib import Graph,URIRef,Literal,RDF,RDFS,OWL,XSD
from rdflib.util import from_n3
from ontoreason_mapping_bridge import inventory_from_state,q
from ontoreason_core import materialize,file_sha
from reasoner_check import check
import model_adapted_framework_v3 as state_tools
TYPE_NAMES={'INTEGER':'integer','INT':'integer','SMALLINT':'integer','BIGINT':'integer','TINYINT':'boolean','BOOLEAN':'boolean','BOOL':'boolean','FLOAT':'float','DOUBLE':'double','DECIMAL':'decimal','NUMERIC':'decimal','TEXT':'string','VARCHAR':'string','CHAR':'string','CLOB':'string','TIMESTAMP':'dateTime','DATETIME':'dateTime','DATE':'date','TIME':'time','BLOB':'base64Binary'}
def physical_xsd(declared_type):
 base=str(declared_type).upper().split('(')[0].strip()
 if base not in TYPE_NAMES:raise ValueError('Unsupported physical SQL datatype: '+str(declared_type))
 return URIRef(str(XSD)+TYPE_NAMES[base])
def datatype_bindings(state,snapshot):
 con=sqlite3.connect(Path(snapshot).resolve().as_uri()+'?mode=ro',uri=True)
 try:
  tables={x[0] for x in con.execute("SELECT name FROM sqlite_master WHERE type='table'")};types={t:{x[1]:x[2] for x in con.execute('PRAGMA table_info('+q(t)+')')} for t in tables}
  result={}
  for key,prop in state['data_properties'].items():
   table,column=key.rsplit('.',1)
   if table not in types or column not in types[table]:raise ValueError('Unknown physical datatype source: '+key)
   dtype=physical_xsd(types[table][column]);old=result.get(prop['uri'])
   if old and old['datatype']!=str(dtype):raise ValueError('One property has conflicting physical types')
   result[prop['uri']]=dict(datatype=str(dtype),declared_sql_type=types[table][column],table=table,column=column)
  return result
 finally:con.close()
def augment_graph(graph,state,snapshot):
 graph=Graph()+graph;bindings=datatype_bindings(state,snapshot)
 for iri,b in bindings.items():
  ranges=list(graph.objects(URIRef(iri),RDFS.range));dtype=URIRef(b['datatype'])
  if ranges and ranges!=[dtype]:raise ValueError('Existing range conflicts with physical datatype: '+iri)
  graph.add((URIRef(iri),RDFS.range,dtype))
 con=sqlite3.connect(Path(snapshot).resolve().as_uri()+'?mode=ro',uri=True)
 try:
  for key,prop in state['object_properties'].items():
   if prop['domain']!=prop['range']:continue
   table,column=key.rsplit('.',1)
   fks=list(con.execute('PRAGMA foreign_key_list('+q(table)+')'))
   if not any(f[3]==column and f[2]==table for f in fks):raise ValueError('Unjustified self-domain/range property: '+key)
   graph.add((URIRef(prop['uri']),RDFS.comment,Literal('Recursive self-reference declared by source foreign key '+key+'; domain equality alone does not imply an individual self-loop.')))
 finally:con.close()
 return graph
def typed_inventory(state,snapshot):
 inventory=copy.deepcopy(inventory_from_state(state,snapshot));bindings=datatype_bindings(state,snapshot)
 for mapping in inventory.values():
  for head in mapping['heads']:
   if head[2].get('kind')=='literal':head[2]['datatype']=bindings[head[1]['value']]['datatype']
 return inventory
def facts_graph(inventory,snapshot):
 graph=Graph()
 for mapping in inventory.values():
  for triple in materialize(mapping,snapshot):
   terms=tuple(from_n3(x) for x in triple)
   if any(isinstance(x,Literal) and getattr(x,'ill_typed',False) is True for x in terms):raise ValueError('Invalid physical datatype lexical value')
   graph.add(terms)
 return graph
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def official_app(packages):
 sys.path.insert(0,str(packages));os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',KMP_DUPLICATE_LIB_OK='TRUE')
 spec=importlib.util.spec_from_file_location('official_rigor_seed_preflight',R/'vendor/rigor/app.py');app=importlib.util.module_from_spec(spec);sys.modules[spec.name]=app;spec.loader.exec_module(app);return app
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=Path('runtime/runs/shared_o0_v2'));ap.add_argument('--packages',type=Path,default=Path(os.environ.get('EVOONT_RIGOR_PACKAGES','runtime/local_dependency')));a=ap.parse_args()
 assert not (a.out/'preflight.json').exists(),'Preserve frozen prior preflight; use fresh output root'
 app=official_app(a.packages);manifest=json.loads((R/'dynamic/dataset_candidate_v1/manifest.json').read_text(encoding='utf-8'));sequences=[x['sequence_id'] for x in manifest if x['split']=='test' and x['template_index']==4 and x['variant']==0];reports=[]
 for seq in sequences:
  folder=a.out/seq;folder.mkdir(parents=True,exist_ok=True);source=R/'dynamic/dataset_candidate_v1/observed'/seq/'t0';snapshot=source/'snapshot.sqlite';ob,_=state_tools.read_observation(source);state=state_tools.initial_state(ob['schema.json']);state['relation_source_mappings']={};old_path=R/'dynamic/independent_review_bundles_v3'/seq/'O0_for_review.ttl';old=Graph().parse(old_path,format='turtle');new=augment_graph(old,state,snapshot)
  added=set(new)-set(old);assert set(old)<=set(new) and all(p in {RDFS.range,RDFS.comment} for s,p,o in added)
  assert all(p!=RDFS.range or (s,RDF.type,OWL.DatatypeProperty) in old for s,p,o in added)
  bindings=datatype_bindings(state,snapshot)
  assert all(URIRef(b['datatype'])==app.get_xsd_type(b['declared_sql_type']) for b in bindings.values()),'Datatype implementation differs from official physical mapping'
  path=folder/'O0.ttl';new.serialize(path,format='turtle');save(folder/'literal_datatypes.json',bindings)
  save(folder/'schema_official.json',{t:dict(columns=x['columns'],foreign_keys=x['foreign_keys']) for t,x in ob['schema.json'].items()});schema=app.load_schema_from_json(folder/'schema_official.json')
  global_report=app.validate_graph_against_rigor(new,{})
  native_seed_report=app.validate_graph_against_rigor(new,schema)
  complete=Graph()+new
  for table in schema:complete+=app.direct_mapping_graph_for_table(table,schema)
  full_report=app.validate_graph_against_rigor(complete,schema)
  inventory=typed_inventory(state,snapshot);save(folder/'mappings.json',inventory)
  logical=dict(status='UNKNOWN',ontology_consistent=None);tbox_result=dict(status='UNKNOWN',ontology_consistent=None)
  try:
   factgraph=facts_graph(inventory,snapshot);(new+factgraph).serialize(folder/'O0_and_materialized_facts.ttl',format='turtle');logical=check(folder/'O0_and_materialized_facts.ttl',folder/'reasoner_TBox_ABox');tbox_result=check(path,folder/'reasoner_TBox')
  except Exception as ex:logical.update(error_type=type(ex).__name__,error=str(ex)[:240])
  report=dict(sequence_id=seq,O0_sha256=file_sha(path),original_O0_sha256=file_sha(old_path),snapshot_sha256=file_sha(snapshot),original_triples=len(old),new_triples=len(new),added_range_count=sum(p==RDFS.range for s,p,o in added),added_recursive_comment_count=sum(p==RDFS.comment for s,p,o in added),original_triples_subset=True,only_range_comment_added=True,datatype_strategy='actual SQLite declared SQL type only; official get_xsd_type; never name-based fix_date_type',official_global_seed_contract=dict(ok=global_report.ok,errors=global_report.errors),official_seed_only_native_schema=dict(ok=native_seed_report.ok,errors=native_seed_report.errors,scope='Native IRI coverage is generated by official deterministic mapping, not required of foreign seed alone'),official_seed_plus_native_direct_mapping_full_validation=dict(ok=full_report.ok,errors=full_report.errors),TBox_reasoner=tbox_result,TBox_ABox_reasoner=logical,API_calls=0,gold_visible=False)
  report['pass']=global_report.ok and full_report.ok and logical['status']=='CONSISTENT' and tbox_result['status']=='CONSISTENT';save(folder/'provenance.json',report);reports.append(report);print(json.dumps(dict(sequence=seq,passed=report['pass'],reasoner=logical['status'])),flush=True)
 save(a.out/'preflight.json',dict(all_pass=all(x['pass'] for x in reports) and len(reports)==8,sequences=reports,seed_sha256={x['sequence_id']:x['O0_sha256'] for x in reports},official_source_sha256=file_sha(R/'vendor/rigor/app.py'),API_calls=0,scope='Additive shared input compatibility validation; not experiment performance; native direct-map names checked after official deterministic merge'))
if __name__=='__main__':main()
