"""Strict observed-SQLite to bounded core mapping compiler. No gold/model reads."""
import hashlib,sqlite3,re
from pathlib import Path
from urllib.parse import quote
RDF_TYPE='http://www.w3.org/1999/02/22-rdf-syntax-ns#type'
def q(x):return '"'+str(x).replace('"','""')+'"'
def constant(x):return dict(kind='constant',value=x)
def inventory_from_state(state,snapshot):
 con=sqlite3.connect(Path(snapshot).resolve().as_uri()+'?mode=ro',uri=True)
 try:return _compile(state,con)
 finally:con.close()
def _compile(state,con):
 tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
 schema={};fks={};pks={}
 for table in tables:
  info=list(con.execute('PRAGMA table_info('+q(table)+')'));schema[table]={x[1]:x for x in info}
  pks[table]=[x[1] for x in sorted(info,key=lambda x:x[5]) if x[5]]
  groups={}
  for fk in con.execute('PRAGMA foreign_key_list('+q(table)+')'):groups.setdefault(fk[0],[]).append(fk)
  if any(len(g)!=1 for g in groups.values()):raise ValueError('Unsupported composite FK: '+table)
  fks[table]=[dict(column=g[0][3],target=g[0][2],target_column=g[0][4]) for g in groups.values()]
  for fk in fks[table]:
   if fk['target'] not in tables:raise ValueError('Unknown FK target: '+table)
   targetcols={r[1] for r in con.execute('PRAGMA table_info('+q(fk['target'])+')')}
   if fk['target_column'] not in targetcols:raise ValueError('Unknown referenced FK column: '+table)
   duplicated=con.execute('SELECT 1 FROM '+q(fk['target'])+' WHERE '+q(fk['target_column'])+' IS NOT NULL GROUP BY '+q(fk['target_column'])+' HAVING COUNT(*)>1 LIMIT 1').fetchone()
   if duplicated:raise ValueError('Ambiguous referenced record identity: '+table+'.'+fk['column'])
   missing=con.execute('SELECT COUNT(*) FROM '+q(table)+' s LEFT JOIN '+q(fk['target'])+' t ON s.'+q(fk['column'])+'=t.'+q(fk['target_column'])+' WHERE s.'+q(fk['column'])+' IS NOT NULL AND t.'+q(fk['target_column'])+' IS NULL').fetchone()[0]
   if missing:raise ValueError('Incomplete referenced records: '+table+'.'+fk['column'])
 def identity(table,cu,alias='s',role='s'):
  if table not in tables:raise ValueError('Unknown mapped table: '+str(table))
  pk=pks[table]
  if not pk:raise ValueError('Missing actual primary key: '+table)
  if len(pk)>1 and (len(pk)!=2 or set(pk)!={f['column'] for f in fks[table]}):
   raise ValueError('Unsupported composite PK: '+table)
  if con.execute('SELECT COUNT(*) FROM '+q(table)+' WHERE '+' OR '.join(q(c)+' IS NULL' for c in pk)).fetchone()[0]:raise ValueError('NULL identity key: '+table)
  columns=[alias+'.'+q(c)+' AS '+q('__'+role+str(i)) for i,c in enumerate(pk)]
  prefix='urn:ontoreason:instance:'+quote(cu,safe='')+'/'
  term=dict(kind='iri',template=prefix+'/'.join('{__'+role+str(i)+'}' for i in range(len(pk))))
  policy=dict(version='actual-pk-v1',entity_class_iri=cu,key_arity=len(pk),component_encoding='UTF8-percent-encoded',null_identity='reject')
  return columns,term,policy
 inventory={}
 def emit(kind,semantic,query,heads,policy,source):
  mid=kind+':'+hashlib.sha256(semantic.encode()).hexdigest()
  value=dict(id=mid,query=query,heads=heads,null_policy='skip_statement',identity_policy=policy,source_provenance=source)
  if mid in inventory and inventory[mid]!=value:raise ValueError('Conflicting duplicate semantic mapping: '+mid)
  inventory[mid]=value
 for table,cu in state['classes'].items():
  if state['source_mappings'].get(table)!=cu:raise ValueError('Missing/conflicting class source mapping: '+table)
  cols,subject,policy=identity(table,cu)
  emit('class',cu,'SELECT '+', '.join(cols)+' FROM '+q(table)+' s',[[subject,constant(RDF_TYPE),constant(cu)]],policy,dict(table=table,primary_key=pks[table]))
 for key,prop in state['data_properties'].items():
  table,column=key.rsplit('.',1)
  if table not in schema or column not in schema[table]:raise ValueError('Unknown data property source: '+key)
  if state['classes'].get(table)!=prop['domain']:raise ValueError('Data property domain/source mismatch: '+key)
  cols,subject,policy=identity(table,prop['domain'])
  query='SELECT '+', '.join(cols+['s.'+q(column)+' AS "__value"'])+' FROM '+q(table)+' s'
  emit('data',prop['uri']+'|'+prop['domain'],query,[[subject,constant(prop['uri']),dict(kind='literal',column='__value')]],policy,dict(table=table,column=column))
 def relation(table,source,target,prop,source_fk=None,target_fk=None):
  if prop['domain']!=state['classes'].get(source) or prop['range']!=state['classes'].get(target):raise ValueError('Object property domain/range mismatch')
  if source_fk:
   joins=' FROM '+q(table)+' a INNER JOIN '+q(source)+' s ON a.'+q(source_fk['column'])+'=s.'+q(source_fk['target_column'])
  else:joins=' FROM '+q(source)+' s'
  joins+=' INNER JOIN '+q(target)+' t ON '+('a.' if target_fk and source_fk else 's.')+q(target_fk['column'])+'=t.'+q(target_fk['target_column'])
  sc,st,sp=identity(source,prop['domain'],'s','s');tc,tt,tp=identity(target,prop['range'],'t','t')
  emit('object',prop['uri'],'SELECT '+', '.join(sc+tc)+joins,[[st,constant(prop['uri']),tt]],dict(source=sp,target=tp),dict(table=table,source_table=source,target_table=target,source_fk=source_fk,target_fk=target_fk))
 def fk_for(table,column,target):
  ff=[f for f in fks.get(table,[]) if f['column']==column and f['target']==target]
  if len(ff)!=1:raise ValueError('Unknown/ambiguous FK role: '+str(table)+'.'+str(column))
  return ff[0]
 associations=state.get('relation_source_mappings',{})
 handled=set()
 for key,provenance in associations.items():
  if provenance.get('kind')!='association':continue
  table=provenance['source_table'];source=provenance['domain_table'];target=provenance['range_table']
  sf=fk_for(table,provenance.get('source_column','source_id'),source);tf=fk_for(table,provenance.get('target_column','target_id'),target)
  if sf['column']==tf['column']:raise ValueError('Association endpoint roles collide')
  if table not in state['classes']:raise ValueError('Missing association relation class')
  for role,endpoint,fk in [('source',source,sf),('target',target,tf)]:
   rolekey=table+'.'+role;prop=state['object_properties'].get(rolekey)
   if not prop:raise ValueError('Missing association endpoint property: '+rolekey)
   relation(table,table,endpoint,prop,target_fk=fk);handled.add(rolekey)
  prop=state['object_properties'].get(key)
  if not prop:raise ValueError('Missing association direct relation')
  relation(table,source,target,prop,source_fk=sf,target_fk=tf);handled.add(key)
 for key,prop in state['object_properties'].items():
  if key in handled:continue
  table,column=key.rsplit('.',1)
  candidates=[f for f in fks.get(table,[]) if f['column']==column and state['classes'].get(f['target'])==prop['range']]
  if len(candidates)!=1:raise ValueError('Unknown mapped direct FK: '+key)
  relation(table,table,candidates[0]['target'],prop,target_fk=candidates[0])
 # SQL aliases are not assigned guessed keys: prove simple SELECT * aliases and
 # exact PK projection/multiset against an existing source, then record provenance.
 for source,cu in state['source_mappings'].items():
  if source in state['classes']:continue
  view=con.execute("SELECT sql FROM sqlite_master WHERE type='view' AND name=?",(source,)).fetchone()
  targets=[t for t,v in state['classes'].items() if v==cu]
  if not view or len(targets)!=1:raise ValueError('Unsupported alias source mapping: '+source)
  canonical=targets[0]
  # Validate value equivalence directly, without relying on the alias name.
  columns=list(schema[canonical]);select=', '.join(q(c) for c in columns)
  if sorted(map(repr,con.execute('SELECT '+select+' FROM '+q(source))))!=sorted(map(repr,con.execute('SELECT '+select+' FROM '+q(canonical)))):
   raise ValueError('Alias view not record-equivalent')
  mid='class:'+hashlib.sha256(cu.encode()).hexdigest();inventory[mid]['source_provenance'].setdefault('verified_equivalent_aliases',[]).append(source)
 return inventory
