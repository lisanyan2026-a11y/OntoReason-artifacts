"""Reuse released compatible O0 without inventing a new seed."""
from pathlib import Path
import shutil
R=Path(__file__).resolve().parent;source=R.parent/'recorded/runs/shared_o0_v2';dest=R/'runtime/runs/shared_o0_v2'
assert not dest.exists(),'Fresh runtime required'
shutil.copytree(source,dest)
print('Copied frozen compatible O0; run hashes and offline preflight are historical evidence, not fresh validation.')
