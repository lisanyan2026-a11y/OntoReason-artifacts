"""Regenerate two full three-category review figures from the released CSV."""
from pathlib import Path
import csv,collections
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=Path(__file__).resolve().parent.parent
with (P/'recorded/metrics/candidate_results.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
out=P/'regenerated_figures';out.mkdir(exist_ok=True)
for key,name in [('ontology_status','ontology_status'),('joint_status','joint_status')]:
 fig,ax=plt.subplots(figsize=(10,4));methods=['RIGOR','OntoReason'];left=[0,0]
 for status,color,label in [('SUPPORTED_ON_APPLICABLE_ITEMS','#347A6B','All applicable supported'),('FAIL','#B75D51','At least one refuted'),('UNDETERMINED','#A2ADBF','Undetermined')]:
  n=[sum(r['method']==m and r[key]==status for r in rows) for m in methods];ax.barh(methods,n,left=left,color=color,label=label)
  for i,v in enumerate(n):
   if v:ax.text(left[i]+v/2,i,str(v),ha='center',va='center')
  left=[x+y for x,y in zip(left,n)]
 ax.set_xlim(0,50);ax.set_xlabel('Candidates per method');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.2),ncol=3);fig.tight_layout();fig.savefig(out/(name+'.png'),dpi=180);plt.close(fig)
print('Regenerated complete review figures; matplotlib is required.')
