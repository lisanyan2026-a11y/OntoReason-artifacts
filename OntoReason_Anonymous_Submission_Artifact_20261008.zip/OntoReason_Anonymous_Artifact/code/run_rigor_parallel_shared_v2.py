"""Three isolated official RIGOR workers; exact frozen contexts, no shared stdout.
Token is read from parent stdin and passed to spawned workers in memory only.
"""
import argparse,contextlib,importlib.util,json,os,random,sys,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path
from run_rigor_shared_o0_v2 import R,contexts,load,digest,schema_for_official
ROOT=Path('runtime/runs/rigor_shared_v2')
APP=None;TRANSPORT=None;CURRENT=None;CALLS=None
def save(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.tmp.'+str(os.getpid()));tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)
def recorded(run,seq,ctx):
 original=ROOT/str(run)/seq/ctx['context_sha256'][:12]
 matches=list(original.parent.glob(original.name+'*/run_manifest.json')) if original.parent.exists() else []
 if len(matches)>1:raise ValueError('Multiple recorded context attempts require adjudication')
 if not matches:return None
 p=matches[0];row=load(p)
 assert row['context_sha256']==ctx['context_sha256'] and row['hashes']==ctx['hashes'] and row['run_id']==run and row['sequence_id']==seq,'Recorded context mismatch'
 if row['status']=='PIPELINE_COMPLETED':assert digest(p.parent/'ontology.owl')==row['ontology_sha256'],'Recorded ontology corrupt'
 return p,row
def provenance(run,seq,ctx,path,row,only_missing=False):
 for t in ctx['times']:
  p=ROOT/str(run)/seq/f't{t}_provenance.json'
  if only_missing and p.exists():continue
  save(p,dict(run_id=run,sequence_id=seq,t=t,status=row['status'],context_sha256=ctx['context_sha256'],current_input_hashes=ctx['hashes'],actual_run_manifest=str(path),actual_ontology=str(path.parent/'ontology.owl') if row['status']=='PIPELINE_COMPLETED' else None,ontology_sha256=row.get('ontology_sha256'),cache_reused=t!=ctx['first_t'],cache_scope='same sequence and run; exact schema/docs/O0 hashes only',actual_rebuild_elapsed_s=row['elapsed_s'],incremental_cache_lookup_latency_s=None,action=None,mapping_status='UNAVAILABLE',semantic_effect_correct=None))
def initialize(token):
 global APP,TRANSPORT,CURRENT,CALLS
 os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',KMP_DUPLICATE_LIB_OK='TRUE')
 sys.path[:0]=[os.environ.get('EVOONT_RIGOR_PACKAGES','runtime/local_dependency'),str(R/'packages_minimal')]
 from anthropic_transport import Transport,BudgetExceeded
 TRANSPORT=Transport(token,R/'runs/api_calls',budget_limit=300)
 spec=importlib.util.spec_from_file_location('pinned_rigor_parallel_app',R/'vendor/rigor/app.py');APP=importlib.util.module_from_spec(spec);sys.modules[spec.name]=APP;spec.loader.exec_module(APP)
 APP.SENT_MODEL=APP.SentenceTransformer(load(R/'rigor_runtime_lock.json')['snapshot_path'],device='cpu',local_files_only=True)
 CURRENT={};CALLS=[]
 class Client:
  def __init__(self,api_key,model):self.model=model
  def generate(self,prompt,temperature=.2,max_tokens=10000,retries=3):
   for retry in range(2):
    previous=getattr(TRANSPORT.local,'last_call_dir',None)
    try:return TRANSPORT([dict(role='user',content=prompt)],min(max_tokens,4096),system='You generate OWL 2 ontology fragments in Manchester Syntax. Return only valid Manchester Syntax and no explanation.',tag=f"rigorparallel_{CURRENT['run']}_{os.getpid()}")
    except BudgetExceeded:raise
    except Exception:
     if retry:raise
    finally:
     latest=getattr(TRANSPORT.local,'last_call_dir',None)
     if latest is not None and latest!=previous:CALLS.append(str(latest))
 APP.OpenRouterLLM=Client;os.environ['OPENROUTER_API_KEY']='transport-injected-placeholder'
def execute(job):
 run,seq,ctx=job
 already=recorded(run,seq,ctx)
 if already:provenance(run,seq,ctx,*already,only_missing=True);return dict(run=run,sequence=seq,status='SKIP_RECORDED')
 out=ROOT/str(run)/seq/ctx['context_sha256'][:12];original=out;attempt=1
 while out.exists():out=original.with_name(original.name+'_parallel'+str(attempt));attempt+=1
 out.mkdir(parents=True);CALLS.clear();CURRENT['run']=run;start=time.perf_counter()
 record=dict(method='RIGOR-Rebuild-shared-compatible-O0-v2/input-cache',run_id=run,sequence_id=seq,**ctx,gold_visible=False,mapping_status='UNAVAILABLE',ontology_reasoner='NOT_RUN',worker_pid=os.getpid(),scheduler='ProcessPoolExecutor context workers, max3',api_seed=None)
 try:
  obs=Path(ctx['observation']);assert digest(obs/'schema.json')==ctx['hashes']['schema'] and digest(obs/'documentation.json')==ctx['hashes']['documentation'] and digest(Path(ctx['o0']))==ctx['hashes']['O0'],'Worker source changed'
  preflight=load(Path('runtime/runs/shared_o0_v2/preflight.json'));assert preflight['all_pass'] and preflight['seed_sha256'][seq]==ctx['hashes']['O0']
  schema=load(obs/'schema.json');save(out/'source_schema.json',schema);save(out/'schema_official.json',schema_for_official(schema))
  docs=out/'docs';docs.mkdir();(docs/'current_documentation.txt').write_text((obs/'documentation.json').read_text(encoding='utf-8'),encoding='utf-8');external=out/'empty_external_ontologies';external.mkdir();o0=out/'fixed_O0.owl';APP.Graph().parse(ctx['o0'],format='turtle').serialize(o0,format='xml')
  record.update(fixed_seed_sha256=digest(o0),seed_rdf_triples=len(APP.Graph().parse(o0,format='xml')))
  random.seed(run);APP.np.random.seed(run)
  import torch
  torch.manual_seed(run)
  with (out/'pipeline.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
   APP.run_semantic_enrichment(schema_path=out/'schema_official.json',docs_path=docs,ontology_path=external,core_owl_path=o0,output_path=out/'ontology.owl',direct_mappings_dir=out/'direct_mappings',model=TRANSPORT.model,use_llm=True)
  graph=APP.Graph().parse(out/'ontology.owl',format='xml');record.update(status='PIPELINE_COMPLETED',rdf_triples=len(graph),ontology_sha256=digest(out/'ontology.owl'))
 except Exception as ex:record.update(status='FAILED',error_type=type(ex).__name__)
 record.update(elapsed_s=time.perf_counter()-start,raw_api_call_paths=sorted(set(CALLS)))
 path=out/'run_manifest.json';save(path,record);provenance(run,seq,ctx,path,record)
 return dict(run=run,sequence=seq,times=ctx['times'],status=record['status'],calls=len(record['raw_api_call_paths']),elapsed_s=record['elapsed_s'])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--resume',action='store_true');ap.add_argument('--plan-only',action='store_true');a=ap.parse_args()
 assert a.resume,'Parallel continuation requires --resume frozen serial plan'
 plan=contexts();frozen=load(ROOT/'plan.json');authorization=load(R/'budget_authorization.json')
 assert authorization['authorized_budget_usd']>=300 and authorization.get('existing_spend_included') is True,'USD300 cumulative authorization required'
 assert frozen['contexts']==plan and frozen['official_source_sha256']==digest(R/'vendor/rigor/app.py') and frozen['vendor_lock']==load(R/'rigor_vendor_lock.json') and frozen['run_ids']==[17,29] and frozen['actual_rebuilds_planned']==22 and frozen['model']=='claude-sonnet-4-6','Frozen plan/context/source mismatch'
 jobs=[(run,s['sequence_id'],ctx) for run in frozen['run_ids'] for s in plan for ctx in s['contexts']];pending=[];skip=[]
 for run,seq,ctx in jobs:
  old=recorded(run,seq,ctx)
  if old:skip.append((run,seq,ctx,old))
  else:pending.append((run,seq,ctx))
 if a.plan_only:print(json.dumps(dict(planned=22,recorded=len(skip),pending=len(pending),workers=3,API_calls=0)));return
 token=sys.stdin.readline().strip();assert token,'stdin credential required; never stored'
 if (ROOT/'completion.json').exists():assert load(ROOT/'completion.json').get('complete') is not True or not pending,'Completed plan has missing contexts'
 save(ROOT/'execution_parallel.json',dict(change='serial to independent-context process pool',changed_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),max_workers=3,plan_sha256=digest(ROOT/'plan.json'),runner_sha256=digest(Path(__file__)),authorization_sha256=digest(R/'budget_authorization.json'),cumulative_budget_cap_usd=300,recorded_skipped=len(skip),pending_contexts=len(pending),preserve_success_and_failure=True,preserve_partial_directories=True,seed_policy_unchanged=True,per_context_host_rng_reset_to_run_label=True,api_seed=None,token_storage='memory-only initializer arguments over process pipe'))
 for run,seq,ctx,old in skip:provenance(run,seq,ctx,*old,only_missing=True)
 failures=[]
 if pending:
  with ProcessPoolExecutor(max_workers=3,initializer=initialize,initargs=(token,)) as pool:
   futures={pool.submit(execute,j):j for j in pending}
   for future in as_completed(futures):
    try:print(json.dumps(future.result()),flush=True)
    except Exception as ex:failures.append(dict(run=futures[future][0],sequence=futures[future][1],context_sha256=futures[future][2]['context_sha256'],error_type=type(ex).__name__))
 if failures:save(ROOT/'execution_parallel_errors.json',failures)
 final=[recorded(*job) for job in jobs];completed=sum(x is not None for x in final)
 if completed==22:save(ROOT/'completion.json',dict(status='ALL_REBUILD_ATTEMPTS_RECORDED',attempted_unique_contexts=22,planned_unique_contexts=22,complete=True,coordinator_pid=os.getpid(),formal_semantic_metrics=False))
 else:save(ROOT/'parallel_incomplete.json',dict(recorded_contexts=completed,planned_contexts=22,coordinator_errors=len(failures),completion_written=False))
 print(json.dumps(dict(recorded_contexts=completed,planned=22,complete=completed==22)),flush=True)
if __name__=='__main__':main()
