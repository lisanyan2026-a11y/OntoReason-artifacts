import copy,unittest
from pathlib import Path
import model_adapted_framework_v3 as m

class V3IntegrityTests(unittest.TestCase):
 def setUp(self):
  root=Path(__file__).parent/'dataset_candidate_v1/observed'
  self.ob,_=m.read_observation(root/'iswc_NewRelation_template_0_variant_0/t1')
  base,_=m.read_observation(root/'iswc_NewRelation_template_0_variant_0/t0')
  self.state=m.initial_state(base['schema.json']);self.state['relation_source_mappings']={}
  self.op=dict(op='add_relation',table='reviews_detail',source_table='persons',target_table='papers')
 def compile(self,op=None,state=None):
  return m.validate_compile(state or self.state,self.ob,dict(operations=[op or self.op]))
 def test_association_three_parts_and_source_mapping(self):
  new,errors,delta=self.compile();self.assertFalse(errors);self.assertTrue(delta)
  self.assertIn('reviews_detail',new['classes']);self.assertIn('reviews_detail.source',new['object_properties'])
  self.assertIn('reviews_detail.target',new['object_properties'])
  self.assertEqual(new['source_mappings']['reviews_detail'],new['classes']['reviews_detail'])
  self.assertFalse(m.validate_relation_integrity(new,self.ob['schema.json']))
 def test_missing_endpoint_or_relation_class_rejected(self):
  new,_,_=self.compile()
  for section,key in [('classes','reviews_detail'),('object_properties','reviews_detail.source'),('object_properties','reviews_detail.target')]:
   bad=copy.deepcopy(new);del bad[section][key]
   self.assertTrue(m.validate_relation_integrity(bad,self.ob['schema.json']))
   result,errors,delta=self.compile(state=bad);self.assertTrue(errors);self.assertEqual(result,bad);self.assertEqual(delta,[])
 def test_idempotent_and_explicit_relation_class(self):
  new,errors,_=self.compile(dict(self.op,op='add_relation_class'));self.assertFalse(errors)
  again,errors,delta=self.compile(state=new);self.assertFalse(errors);self.assertEqual(delta,[]);self.assertEqual(new,again)
  again,errors,delta=m.validate_compile(new,self.ob,dict(operations=[dict(op='add_class',table='reviews_detail'),self.op,self.op]));self.assertFalse(errors);self.assertEqual(delta,[])
 def test_inverse_fk_rejected(self):
  new,errors,delta=self.compile(dict(self.op,source_table='papers',target_table='persons'))
  self.assertTrue(errors);self.assertEqual(new,self.state);self.assertEqual(delta,[])
 def test_rename_export_binds_new_column_to_old_iri(self):
  root=Path(__file__).parent/'dataset_candidate_v1/observed/iswc_Rename_template_0_variant_0'
  b,_=m.read_observation(root/'t0');o,_=m.read_observation(root/'t1');state=m.initial_state(b['schema.json'])
  old=state['data_properties']['conferences.Name']['uri'];new=m.mechanical_reuse(state,o)
  mapping=m.source_mappings(new)['data_property_source_mappings']
  self.assertEqual(mapping['conferences.Name_display']['uri'],old);self.assertNotIn('conferences.Name',mapping)

if __name__=='__main__':unittest.main()
