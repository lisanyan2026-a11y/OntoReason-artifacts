"""Executable bounded OntoReason core, distinct from the v3 RDB adaptation.

Evidence checks are injected independently of proposal generation. Unsupported or
unknown evidence never becomes support. Publication requires a supplied actual
reasoner contract; absence of a reasoner cannot silently pass validation.
"""
import collections,dataclasses,hashlib,json,os,sqlite3,uuid,time,contextlib,functools,re
from pathlib import Path
from urllib.parse import quote
from rdflib import Graph,URIRef,Literal,RDF,OWL

VERSION='ontoreason-core-0.1'
def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
def file_sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

class Registry:
    """Registered input -> consumer dependencies; read needs are separate edges."""
    def __init__(self,consumers,read_needs):
        self.consumers={k:set(v) for k,v in consumers.items()}
        self.read_needs={k:set(v) for k,v in read_needs.items()}
        self.nodes=set(consumers)|set(read_needs)
        for values in list(self.consumers.values())+list(self.read_needs.values()):self.nodes.update(values)
    def closure(self,seeds):
        seen=set(seeds)
        if not seen<=self.nodes:raise ValueError('Unregistered change seed; broaden registration first')
        queue=list(seen)
        while queue:
            for v in self.consumers.get(queue.pop(),set())-seen:seen.add(v);queue.append(v)
        return seen
    def refine(self,seeds,check_boundary):
        region=self.closure(seeds);trace=[];bound=len(self.nodes)-len(region)
        while True:
            boundary=set().union(*(self.read_needs.get(v,set()) for v in region))-region
            results={v:check_boundary(v) for v in sorted(boundary)}
            if any(v not in {'SUPPORTED','REFUTED','UNKNOWN'} for v in results.values()):raise ValueError('Bad boundary result')
            promote={v for v,r in results.items() if r!='SUPPORTED'}
            trace.append(dict(region=sorted(region),boundary=results,promoted=sorted(promote)))
            if not promote:return region,trace
            new=self.closure(region|promote)
            if not region<new:raise AssertionError('Non-monotone refinement')
            region=new
            if len(trace)>bound:raise AssertionError('Finite refinement bound exceeded')

@dataclasses.dataclass(frozen=True)
class Obligation:
    id:str
    checker:str
    proposition:str
    sources:tuple # (absolute path, frozen SHA256) pairs; original source material
    authority:str
    identity_policy:str

@dataclasses.dataclass
class Event:
    id:str
    requires:set
    obligations:list
    ontology_add:str=''
    mapping_updates:dict=dataclasses.field(default_factory=dict)
    alternatives_resolved:bool=True
    interpretation:str='EVOLVE'
    def binding(self):
        return digest(dict(interpretation=self.interpretation,id=self.id,requires=sorted(self.requires),obligations=[dataclasses.asdict(o) for o in self.obligations],ontology_add=self.ontology_add,mapping_updates=self.mapping_updates,alternatives_resolved=self.alternatives_resolved))

class Assessor:
    def __init__(self,checkers,versions):
        required={'checker','compiler','model','prompt','search_scope'}
        if not required<=set(versions):raise ValueError('Incomplete assessment-version binding')
        self.checkers=checkers;self.versions=versions;self.cache={}
    def assess(self,event):
        outcomes=[]
        for ob in event.obligations:
            bound=ob.sources and ob.authority and ob.identity_policy
            if not bound or any(not Path(p).is_file() or file_sha(p)!=sha for p,sha in ob.sources):
                outcomes.append(dict(id=ob.id,status='UNKNOWN',reason='Missing or stale original-source binding'));continue
            key=digest([event.binding(),dataclasses.asdict(ob),self.versions])
            if key not in self.cache:
                checker=self.checkers.get(ob.checker)
                result=checker(event,ob) if checker else dict(status='UNKNOWN',reason='No independent checker registered')
                if result.get('status') not in {'SUPPORTED','REFUTED','UNKNOWN'}:raise ValueError('Bad evidence assessment')
                self.cache[key]=dict(result)
            outcomes.append(dict(id=ob.id,**self.cache[key]))
        statuses=[o['status'] for o in outcomes]
        overall='REFUTED' if 'REFUTED' in statuses else 'SUPPORTED' if statuses and all(s=='SUPPORTED' for s in statuses) else 'UNKNOWN'
        return dict(event_id=event.id,candidate_binding=event.binding(),status=overall,outcomes=outcomes,versions=dict(self.versions))

def acquire_unknown(pending,actions,inspect,budget):
    """Greedy untried acquisition with stable ties; observations, not approvals."""
    remaining=set(pending);tried=set();observations=[]
    while remaining and len(tried)<budget:
        candidates=[(len(set(a['covers'])&remaining),a['id'],a) for a in actions if a['id'] not in tried]
        candidates=[a for a in candidates if a[0]>0]
        if not candidates:break
        _,_,action=sorted(candidates,key=lambda v:(-v[0],v[1]))[0]
        tried.add(action['id']);result=inspect(action)
        observations.append(dict(action_id=action['id'],observation=result))
        remaining-=set(result.get('resolved_obligations',[]))&set(action['covers'])
    return observations,remaining

def scc(events):
    if any(k!=e.id for k,e in events.items()):raise ValueError('Event key/id mismatch')
    graph={e.id:set(e.requires)&set(events) for e in events.values()};index={};low={};stack=[];active=set();groups=[]
    def visit(v):
        index[v]=low[v]=len(index);stack.append(v);active.add(v)
        for w in sorted(graph[v]):
            if w not in index:visit(w);low[v]=min(low[v],low[w])
            elif w in active:low[v]=min(low[v],index[w])
        if low[v]==index[v]:
            group=[]
            while True:
                w=stack.pop();active.remove(w);group.append(w)
                if w==v:break
            groups.append(tuple(sorted(group)))
    for v in sorted(graph):
        if v not in index:visit(v)
    return groups

def select(events,assessments,conflicts=(),historical=()):
    if len(events)!=len({e.id for e in events.values()}):raise ValueError('Duplicate event identifier')
    groups=scc(events);groupof={e:i for i,g in enumerate(groups) for e in g};requires={i:set() for i in range(len(groups))};unavailable={};historical=set(historical)
    for i,g in enumerate(groups):
        for name in g:
            e=events[name];a=assessments.get(name,{})
            if a.get('candidate_binding')!=e.binding() or a.get('status')!='SUPPORTED' or not e.alternatives_resolved:unavailable.setdefault(i,[]).append('ineligible_or_stale:'+name)
            for dep in e.requires:
                if dep in groupof and groupof[dep]!=i:requires[i].add(groupof[dep])
                elif dep not in groupof and dep not in historical:unavailable.setdefault(i,[]).append('missing_prerequisite:'+dep)
    conflict_groups=set()
    for a,b in conflicts:
        if a not in groupof or b not in groupof:raise ValueError('Unregistered conflict')
        i,j=groupof[a],groupof[b]
        if i==j:unavailable.setdefault(i,[]).append('internal_conflict')
        else:conflict_groups.add(frozenset((i,j)))
    changed=True
    while changed:
        changed=False
        for i,deps in requires.items():
            if i not in unavailable and deps&set(unavailable):unavailable[i]=['unavailable_prerequisite'];changed=True
    selected=set();visited=set();order=[]
    def admit(i):
        if i in visited:return
        visited.add(i)
        for j in sorted(requires[i],key=lambda n:groups[n]):admit(j)
        if i in unavailable or not requires[i]<=selected:return
        if any(frozenset((i,j)) in conflict_groups for j in selected):unavailable[i]=['conflicts_with_selected'];return
        selected.add(i);order.extend(groups[i])
    for i in sorted(requires,key=lambda n:groups[n]):admit(i)
    return dict(selected=order,groups=[list(g) for g in groups],unavailable={','.join(groups[i]):why for i,why in unavailable.items()})

def query_rows(snapshot,sql):
    if not sql.lstrip().upper().startswith(('SELECT','WITH')):raise ValueError('Only read queries supported')
    con=sqlite3.connect(Path(snapshot).resolve().as_uri()+'?mode=ro',uri=True);con.row_factory=sqlite3.Row
    allowed={sqlite3.SQLITE_SELECT,sqlite3.SQLITE_READ,sqlite3.SQLITE_FUNCTION,sqlite3.SQLITE_RECURSIVE}
    con.set_authorizer(lambda action,*args:sqlite3.SQLITE_OK if action in allowed else sqlite3.SQLITE_DENY)
    try:return [dict(r) for r in con.execute(sql)]
    finally:con.close()

def term(spec,row):
    if spec['kind']=='constant':return URIRef(spec['value'])
    if spec['kind']=='iri':
        text=spec['template']
        import re
        columns=re.findall(r'\{([^{}]+)\}',text)
        if any(row[c] is None for c in columns):return None
        for c in columns:text=text.replace('{'+c+'}',quote(str(row[c]),safe=''))
        return URIRef(text)
    if spec['kind']=='literal':
        value=row[spec['column']]
        return None if value is None else Literal(value,datatype=URIRef(spec['datatype']) if spec.get('datatype') else None)
    raise ValueError('Unsupported term constructor')

def materialize(mapping,snapshot):
    if mapping.get('null_policy')!='skip_statement':raise ValueError('Unsupported or missing NULL policy')
    facts=set()
    for row in query_rows(snapshot,mapping['query']):
        for head in mapping['heads']:
            triple=tuple(term(t,row) for t in head)
            if None not in triple:facts.add(tuple(x.n3() for x in triple))
    return facts

def verify_repair(old,new,old_snapshot,new_snapshot):
    if any(old.get(k)!=new.get(k) for k in ['id','heads','null_policy','identity_policy']):return dict(preserved=False,reason='Changed head/identity/NULL contract')
    old_rows=query_rows(old_snapshot,old['query']);new_rows=query_rows(new_snapshot,new['query'])
    tuples=lambda rows:collections.Counter(json.dumps(r,sort_keys=True) for r in rows)
    same=tuples(old_rows)==tuples(new_rows)
    facts=materialize(old,old_snapshot)==materialize(new,new_snapshot)
    return dict(preserved=same and facts,complete_tuple_multiset_equal=same,fact_set_equal=facts,scope='finite bound snapshots and fixed head only')

@contextlib.contextmanager
def writer_lock(root):
    path=Path(root)/'.writer.lock'
    with path.open('a+b') as f:
        f.seek(0,2)
        if not f.tell():f.write(b'0');f.flush()
        f.seek(0);deadline=time.monotonic()+30
        while True:
            try:
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
                break
            except (OSError,BlockingIOError):
                if time.monotonic()>deadline:raise TimeoutError('Publication writer lock busy')
                time.sleep(.05)
        try:yield
        finally:
            f.seek(0)
            if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(f,fcntl.LOCK_UN)

def serialized(fn):
    @functools.wraps(fn)
    def wrapped(self,*args,**kwargs):
        with writer_lock(self.root):return fn(self,*args,**kwargs)
    return wrapped

def freeze_snapshot(source,target):
    # SQLite backup captures one consistent database state, including WAL pages.
    src=sqlite3.connect(Path(source).resolve().as_uri()+'?mode=ro',uri=True)
    dst=sqlite3.connect(target)
    try:src.backup(dst);dst.commit()
    finally:dst.close();src.close()
    return file_sha(target)

class Store:
    def __init__(self,root):self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
    def head(self):
        p=self.root/'HEAD.json';return json.loads(p.read_text(encoding='utf-8')) if p.exists() else None
    @serialized
    def publish(self,parent,ontology,mappings,snapshot,selection,events,assessments,reasoner,fail_before_head=False,conflicts=(),assessor=None):
        if self.head()!=parent:raise ValueError('Parent version changed')
        if any(k!=e.id for k,e in events.items()):raise ValueError('Event key/id mismatch')
        chosen=set(selection['selected'])
        if not chosen<=set(events) or len(chosen)!=len(selection['selected']):raise ValueError('Invalid selected events')
        if any({a,b}<=chosen for a,b in conflicts):raise ValueError('Conflicting selected events')
        if chosen and assessor is None:raise ValueError('Independent source-bound assessor required')
        if parent:
            base=self.root/'versions'/parent['version']
            if file_sha(base/'ontology.ttl')!=parent['ontology_sha256'] or file_sha(base/'mappings.json')!=parent['mappings_sha256']:raise ValueError('Corrupt accepted inventory')
            from rdflib.compare import isomorphic
            if not isomorphic(Graph().parse(data=ontology,format='turtle'),Graph().parse(base/'ontology.ttl',format='turtle')) or mappings!=json.loads((base/'mappings.json').read_text(encoding='utf-8')):raise ValueError('Base inventory changed outside declared patches')
            if file_sha(parent['snapshot'])!=parent['snapshot_sha256']:raise ValueError('Corrupt accepted snapshot')
        version=uuid.uuid4().hex;directory=self.root/'versions'/version;directory.mkdir(parents=True)
        source_snapshot=Path(snapshot).resolve()
        bound=freeze_snapshot(source_snapshot,directory/'snapshot.sqlite');snapshot=directory/'snapshot.sqlite'
        for name in chosen:
            a=assessor.assess(events[name]);assessments=dict(assessments);assessments[name]=a
        for name in chosen:
            event=events[name];a=assessments[name]
            if event.interpretation not in {'REUSE','REPAIR','EVOLVE'}:raise ValueError('Unsupported interpretation')
            if a.get('candidate_binding')!=event.binding() or a.get('status')!='SUPPORTED' or not event.alternatives_resolved:raise ValueError('Stale or unsupported publication assessment')
            historical=set(parent.get('accepted_events',[])) if parent else set()
            if not event.requires<=chosen|historical:raise ValueError('Publication lacks prerequisite closure')
        graph=Graph().parse(data=ontology,format='turtle');updated=json.loads(json.dumps(mappings));written={}
        for name in selection['selected']:
            event=events[name]
            if event.ontology_add:graph+=Graph().parse(data=event.ontology_add,format='turtle')
            for mid,mapping in event.mapping_updates.items():
                if mid in written and written[mid]!=mapping:raise ValueError('Conflicting mapping writes')
                written[mid]=mapping;updated[mid]=mapping
        for name in chosen:
            event=events[name]
            if event.interpretation=='REUSE' and (event.ontology_add or event.mapping_updates):raise ValueError('REUSE cannot mutate accepted inventory')
            if event.interpretation=='REPAIR':
                if parent is None or event.ontology_add:raise ValueError('Repair needs fixed parent ontology')
                for mid,new_mapping in event.mapping_updates.items():
                    if mid not in mappings or not verify_repair(mappings[mid],new_mapping,parent['snapshot'],snapshot)['preserved']:raise ValueError('Repair fails complete fact-preservation contract')
        mapped_facts=Graph()
        for mid,mapping in updated.items():
            if mid!=mapping.get('id'):raise ValueError('Mapping identifier mismatch')
            if not mapping.get('identity_policy'):raise ValueError('Missing identity policy')
            for head in mapping['heads']:
                predicate=head[1]
                if predicate.get('kind')!='constant':raise ValueError('Variable predicates unsupported')
                p=URIRef(predicate['value'])
                if p==RDF.type:
                    obj=head[2]
                    if obj.get('kind')!='constant' or (URIRef(obj['value']),RDF.type,OWL.Class) not in graph:raise ValueError('Undeclared mapped class')
                elif (p,RDF.type,OWL.ObjectProperty) not in graph and (p,RDF.type,OWL.DatatypeProperty) not in graph:raise ValueError('Undeclared mapped property')
            from rdflib.util import from_n3
            for fact in materialize(mapping,snapshot):
                triple=tuple(from_n3(v) for v in fact)
                if not isinstance(triple[0],URIRef) or not isinstance(triple[1],URIRef):raise ValueError('Non-IRI mapped subject/predicate')
                if (triple[1],RDF.type,OWL.ObjectProperty) in graph and not isinstance(triple[2],URIRef):raise ValueError('Literal object for object property')
                if (triple[1],RDF.type,OWL.DatatypeProperty) in graph and not isinstance(triple[2],Literal):raise ValueError('IRI object for datatype property')
                for term_value in triple:
                    if isinstance(term_value,URIRef) and (not re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:',str(term_value)) or re.search(r'\s',str(term_value))):raise ValueError('Non-absolute or malformed mapped IRI')
                mapped_facts.add(triple)
        if chosen and all(events[n].interpretation=='REPAIR' for n in chosen):
            old_facts=set().union(*(materialize(m,parent['snapshot']) for m in mappings.values()))
            new_facts=set().union(*(materialize(m,snapshot) for m in updated.values()))
            if old_facts!=new_facts:raise ValueError('Inherited inventory facts changed during repair-only publication')
        if reasoner is None:raise ValueError('Actual complete-ontology reasoning contract required')
        if reasoner(graph+mapped_facts) is not True:raise ValueError('Ontology consistency false or UNKNOWN')
        if file_sha(snapshot)!=bound:raise ValueError('Frozen validation snapshot changed')
        if freeze_snapshot(source_snapshot,directory/'boundary_check.sqlite')!=bound:raise ValueError('Source snapshot changed during validation')
        for name in chosen:
            if assessor.assess(events[name])!=assessments[name]:raise ValueError('Evidence changed during validation')
        graph.serialize(directory/'ontology.ttl',format='turtle')
        (directory/'mappings.json').write_text(json.dumps(updated,indent=2),encoding='utf-8')
        manifest=dict(version=version,parent=parent,ontology_sha256=file_sha(directory/'ontology.ttl'),mappings_sha256=file_sha(directory/'mappings.json'),snapshot=str(Path(snapshot).resolve()),snapshot_sha256=bound,accepted_events=sorted(chosen|(set(parent.get('accepted_events',[])) if parent else set())),implementation=VERSION,assessments={n:assessments[n] for n in chosen})
        (directory/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
        for frozen in directory.iterdir():
            if frozen.is_file():
                with frozen.open('r+b') as f:os.fsync(f.fileno())
        # Atomic pointer replacement plus fsynced files; power-loss guarantees on
        # Windows depend on filesystem semantics, distinct from failure atomicity.
        if fail_before_head:raise RuntimeError('Injected publication failure; HEAD unchanged')
        if file_sha(snapshot)!=bound or self.head()!=parent:raise ValueError('Boundary or parent changed before joint publication')
        temporary=self.root/('HEAD.'+version+'.tmp')
        with temporary.open('w',encoding='utf-8') as f:json.dump(manifest,f,indent=2);f.flush();os.fsync(f.fileno())
        os.replace(temporary,self.root/'HEAD.json') # single authoritative pointer advances all components
        return manifest
