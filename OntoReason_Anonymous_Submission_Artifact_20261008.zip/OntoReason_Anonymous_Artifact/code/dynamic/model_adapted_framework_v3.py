"""RDB selective-evolution ADAPTATION, not original EvoOnt or official RIGOR.

Injection: transport(messages, max_tokens) -> {content,usage,model,request_id?}.
No credentials/network implementation here. No oracle reads or formal gold audit.
"""
import copy, hashlib, json, time
from pathlib import Path
from rule_evolution_diagnostic import read_observation, initial_state, turtle, uri, save

IMPLEMENTATION_VERSION='rdb-adapted-v3-relation-class-idempotent-property-mappings'
METHODS={'EvoOnt-RDB-adapted-base','EvoOnt-RDB-adapted-w/o-Gate','EvoOnt-RDB-adapted-w/o-Temporal'}

def check_turtle(text):
    try:
        from rdflib import Graph
        Graph().parse(data=text,format='turtle')
        return 'PASS'
    except ImportError:return 'UNAVAILABLE_rdflib'
    except Exception:return 'FAIL'
SYSTEM='''You propose ontology evolution operations from currently visible relational evidence.
Distinguish source renaming/aliases from independent concepts and relationships. Missing
business meaning or missing endpoints is uncertainty. Never invent future evidence.
Return JSON only: {"interpretation":"supported|uncertain|conflicting",
"semantic_confidence":0.0,"reason":"specific visible evidence",
"operations":[{"op":"add_class","table":"current table"},
{"op":"add_relation","table":"current association table","source_table":"existing or proposed class table","target_table":"existing or proposed class table"},
{"op":"map_alias","source":"current view or table","target":"known class table"}]}
Do not propose new classes for already represented concepts or ordinary records.
semantic_confidence is an uncalibrated proposal score, not a correctness estimate.
The independent validator, not you, decides operation validity. No gold is available.'''
SYSTEM+=''' For a direct FK relation, table must equal source_table and target_table
must be referenced by that table; add optional column to disambiguate multiple FKs.
For an association relation, table is an intermediary with FK references to both
source_table and target_table. New class and its FK relation may be proposed together.
Class/alias mappings and relation_source_mapping are separate provenance categories;
do not create another class simply because a table is already mapped as a relation.'''
SYSTEM+=''' Association add_relation is represented by an intermediary relation class,
its source and target endpoint object properties, and the direct relation.
add_relation_class is an explicit synonym with the same table/source_table/target_table
fields. Equivalent already represented operations are no-ops, not new extensions.'''

def mechanical_reuse(state,ob):
    new=copy.deepcopy(state);ev=ob['event.json'];sch=ob['schema.json']
    if ev.get('change')=='table_renamed':
        a,b=ev['before'],ev['after']
        if a in new['classes'] and b in sch and a not in sch:
            cu=new['classes'].pop(a);new['classes'][b]=cu
            new['source_mappings'].pop(a,None);new['source_mappings'][b]=cu
            for key in list(new['data_properties']):
                if key.startswith(a+'.'):new['data_properties'][b+key[len(a):]]=new['data_properties'].pop(key)
    elif ev.get('change')=='column_renamed':
        t=ev['table'];a=t+'.'+ev['before'];b=t+'.'+ev['after']
        if a in new['data_properties'] and ev['after'] in sch.get(t,{}).get('columns',{}):
            new['data_properties'][b]=new['data_properties'].pop(a)
    return new

def parse_proposal(response):
    content=response['content']
    if isinstance(content,dict):p=content
    else:
        s=content.strip()
        if s.startswith('```'):s='\n'.join(s.splitlines()[1:-1])
        p=json.loads(s)
    if p.get('interpretation') not in {'supported','uncertain','conflicting'}:raise ValueError('Invalid interpretation')
    score=p['semantic_confidence']
    if type(score) not in {int,float} or not 0<=score<=1:raise ValueError('Invalid semantic score')
    if not isinstance(p['operations'],list):raise ValueError('operations must be a list')
    return p

def _v2_validate_compile(state,ob,proposal):
    """Independent of model scores/gold: source membership, endpoints, FK direction.

    This checks graph construction integrity, not all semantic correctness/OWL DL.
    """
    schema=ob['schema.json'];new=copy.deepcopy(state);errors=[]
    new.setdefault('relation_source_mappings',{})
    ops=proposal['operations'];seen=set()
    for op in ops:
        key=json.dumps(op,sort_keys=True)
        if key in seen:errors.append('duplicate_operation')
        seen.add(key)
        typ=op.get('op')
        if typ=='add_class':
            t=op.get('table')
            if t not in schema:errors.append('unknown_source_table:'+str(t));continue
            if t in new['source_mappings']:errors.append('already_mapped_class:'+t);continue
            cu=uri('class',t);new['classes'][t]=cu;new['source_mappings'][t]=cu
            for c in schema[t]['columns']:
                key=t+'.'+c;new['data_properties'][key]={'uri':uri('data',key),'domain':cu}
        elif typ not in {'add_relation','map_alias'}:errors.append('unknown_operation:'+str(typ))
    for op in ops:
        if op.get('op')=='map_alias':
            source,target=op.get('source'),op.get('target')
            if source not in schema and source not in ob['views.json']:errors.append('unknown_alias_source')
            elif target not in new['classes']:errors.append('unknown_alias_target')
            else:new['source_mappings'][source]=new['classes'][target]
        elif op.get('op')=='add_relation':
            table,source,target=op.get('table'),op.get('source_table'),op.get('target_table')
            if table not in schema:errors.append('unknown_relation_table');continue
            fks=schema[table]['foreign_keys'];refs={f['references_table'] for f in fks}
            if source not in new['classes'] or target not in new['classes']:errors.append('missing_mapped_relation_endpoint');continue
            if table==source:
                # Direct FK: the source is this table itself, not another referenced
                # table. Only the target must be in this table's FK declarations.
                candidates=[f for f in fks if f['references_table']==target and
                            (not op.get('column') or f['column']==op['column'])]
                if len(candidates)!=1:
                    errors.append('direct_fk_target_missing_or_ambiguous');continue
                fk=candidates[0];key=table+'.'+fk['column']
                provenance=dict(kind='direct_fk',source_table=table,source_column=fk['column'],
                                target_table=target,target_column=fk['references_column'])
            else:
                if source not in refs or target not in refs:
                    errors.append('association_endpoints_not_supported_by_fk');continue
                sf=[f for f in fks if f['column']=='source_id'];tf=[f for f in fks if f['column']=='target_id']
                if sf and tf and (sf[0]['references_table']!=source or tf[0]['references_table']!=target):
                    errors.append('relation_direction_disagrees_with_source_roles');continue
                key=table;provenance=dict(kind='association',source_table=table,
                                         domain_table=source,range_table=target,foreign_keys=fks)
            if key in new['object_properties']:errors.append('duplicate_existing_relation');continue
            property_uri=uri('object',key)
            new['object_properties'][key]={'uri':property_uri,'domain':new['classes'][source],'range':new['classes'][target]}
            new['relation_source_mappings'][key]=dict(uri=property_uri,**provenance)
            # Never replace a source table's class mapping with its relation IRI.
    # All FK dependencies of proposed source objects must be physically present.
    for op in ops:
        for fk in schema.get(op.get('table'),{}).get('foreign_keys',[]):
            if fk['references_table'] not in schema:errors.append('missing_declared_dependency')
    if errors:return state,sorted(set(errors)),[]
    before=set(turtle(state).splitlines());after=set(turtle(new).splitlines())
    return new,[],sorted(after-before)

def source_mappings(s):
    return dict(class_or_alias_source_mappings=s['source_mappings'],
                relation_source_mappings=s.get('relation_source_mappings',{}),
                data_property_source_mappings={k:dict(uri=v['uri'],domain=v['domain'])
                    for k,v in s['data_properties'].items()})

def validate_relation_integrity(state,schema):
    """Check every compiled association class and its two role properties atomically."""
    errors=[]
    for key,p in state.get('relation_source_mappings',{}).items():
        if p.get('kind')!='association':continue
        table=p.get('source_table');source=p.get('domain_table');target=p.get('range_table')
        cu=state['classes'].get(table)
        if not cu or state['source_mappings'].get(table)!=cu:
            errors.append('association_missing_relation_class:'+str(table));continue
        fks=schema.get(table,{}).get('foreign_keys',[])
        for role,endpoint in [('source',source),('target',target)]:
            col=p.get(role+'_column');refs=[f for f in fks if f['column']==col]
            prop=state['object_properties'].get(str(table)+'.'+role)
            expected=state['classes'].get(endpoint)
            if len(refs)!=1 or refs[0]['references_table']!=endpoint or refs[0]['references_column'] not in schema.get(endpoint,{}).get('columns',{}):
                errors.append('association_invalid_fk_role:'+str(table)+'.'+role)
            if not expected or not prop or prop.get('domain')!=cu or prop.get('range')!=expected:
                errors.append('association_missing_or_conflicting_endpoint:'+str(table)+'.'+role)
        direct=state['object_properties'].get(key)
        if not direct or direct.get('domain')!=state['classes'].get(source) or direct.get('range')!=state['classes'].get(target):
            errors.append('association_direct_relation_conflict:'+str(table))
    return sorted(set(errors))

def validate_compile(state,ob,proposal):
    # Same evidence/Gate as v2. Normalize equivalent existing operations to no-op;
    # source role and integrity checks still run before any candidate is committed.
    schema=ob['schema.json'];ops=[];associations=[];errors=[];seen=set()
    prior_errors=validate_relation_integrity(state,schema)
    if prior_errors:return state,prior_errors,[]
    for raw in proposal['operations']:
        op=copy.deepcopy(raw)
        if op.get('op')=='add_relation_class':op['op']='add_relation'
        sig=json.dumps(op,sort_keys=True)
        if sig in seen:continue
        seen.add(sig);typ=op.get('op');table=op.get('table')
        if typ=='add_class' and table in state['classes']:
            if table not in schema or state['source_mappings'].get(table)!=state['classes'][table]:errors.append('conflicting_existing_class_mapping')
            continue
        if typ=='map_alias' and op.get('source') in state['source_mappings']:
            if state['source_mappings'][op['source']]!=state['classes'].get(op.get('target')):errors.append('conflicting_existing_alias_mapping')
            continue
        if typ=='add_relation' and table in schema:
            source,target=op.get('source_table'),op.get('target_table');fks=schema[table]['foreign_keys']
            if table!=source:
                sf=[f for f in fks if f['column']==op.get('source_column','source_id')]
                tf=[f for f in fks if f['column']==op.get('target_column','target_id')]
                if len(sf)!=1 or len(tf)!=1 or sf[0]['column']==tf[0]['column'] or sf[0]['references_table']!=source or tf[0]['references_table']!=target:
                    errors.append('relation_direction_or_role_missing');continue
                associations.append((table,source,target,sf[0],tf[0]));key=table
            else:
                ff=[f for f in fks if f['references_table']==target and (not op.get('column') or f['column']==op['column'])]
                if len(ff)!=1:errors.append('direct_fk_target_missing_or_ambiguous');continue
                key=table+'.'+ff[0]['column']
            old=state['object_properties'].get(key)
            if old:
                if old['domain']!=state['classes'].get(source) or old['range']!=state['classes'].get(target):errors.append('conflicting_existing_relation')
                continue
        ops.append(op)
    if errors:return state,sorted(set(errors)),[]
    normalized=dict(proposal,operations=ops)
    new,errors,_=_v2_validate_compile(state,ob,normalized)
    if errors:return state,errors,[]
    for table,source,target,sf,tf in associations:
        cu=new['classes'].get(table,uri('class',table))
        if table in new['source_mappings'] and new['source_mappings'][table]!=cu:
            errors.append('conflicting_relation_class_mapping');continue
        new['classes'][table]=cu;new['source_mappings'][table]=cu
        for col in schema[table]['columns']:
            key=table+'.'+col
            if key not in new['data_properties']:new['data_properties'][key]=dict(uri=uri('data',key),domain=cu)
        for role,endpoint,fk in [('source',source,sf),('target',target,tf)]:
            key=table+'.'+role;expected=dict(uri=uri('object',key),domain=cu,range=new['classes'][endpoint])
            if key in new['object_properties'] and new['object_properties'][key]!=expected:
                errors.append('conflicting_relation_role_property');continue
            new['object_properties'][key]=expected
        new['relation_source_mappings'][table].update(relation_class_iri=cu,source_column=sf['column'],target_column=tf['column'])
    # FK membership is checked also for normalized no-op operations.
    for op in proposal['operations']:
        for fk in schema.get(op.get('table'),{}).get('foreign_keys',[]):
            if fk['references_table'] not in schema:errors.append('missing_declared_dependency')
            elif fk['references_column'] not in schema[fk['references_table']]['columns']:
                errors.append('missing_referenced_fk_column')
    errors+=validate_relation_integrity(new,schema)
    if errors:return state,sorted(set(errors)),[]
    return new,[],sorted(set(turtle(new).splitlines())-set(turtle(state).splitlines()))

def temporal_evidence(history,ob,operations):
    """Only past/current observed presence; never require three windows for documented new concepts."""
    schema=ob['schema.json'];docs=ob['documentation.json'].get('tables',{})
    scores=[]
    for op in operations:
        table=op.get('table',op.get('source'))
        repeated=sum(table in old['schema.json'] for old in history)
        documented=bool(docs.get(table)) and 'unverified' not in docs.get(table,'').lower()
        scores.append(1.0 if documented else min(1.0,repeated/2))
    return min(scores) if scores else 1.0

def run_sequence(sequence_dir,out,method,threshold,run_id,transport,max_tokens=2048):
    if method=='RIGOR-Rebuild':
        raise NotImplementedError('Use actual pinned official RIGOR pipeline bridge; generic LLM adaptation is not RIGOR')
    if method not in METHODS:raise ValueError('Unsupported/incorrectly named method')
    if out.exists() and any(out.iterdir()):raise ValueError('Fresh output path required; no hidden cache reuse')
    out.mkdir(parents=True,exist_ok=True)
    initial,_=read_observation(sequence_dir/'t0');state=initial_state(initial['schema.json']);history=[initial]
    state['relation_source_mappings']={key:dict(uri=value['uri'],kind='initial_direct_fk')
                                       for key,value in state['object_properties'].items()}
    mappings=source_mappings
    (out/'O0.ttl').write_text(turtle(state),encoding='utf-8');save(out/'O0_mapping.json',mappings(state))
    rows=[]
    for t in range(1,5):
        start=time.perf_counter();ob,hashes=read_observation(sequence_dir/('t'+str(t)))
        base=mechanical_reuse(state,ob)
        history_payload=[] if method.endswith('w/o-Temporal') else [
            dict(tables=sorted(x['schema.json']),
                 row_counts={k:v.get('row_count') for k,v in x['schema.json'].items()},
                 documented_tables=sorted(x['documentation.json'].get('tables',{})),
                 documentation_sha256=hashlib.sha256(json.dumps(x['documentation.json'],sort_keys=True).encode()).hexdigest())
            for x in history]
        payload={'current_observation':ob,'current_ontology':{'classes':base['classes'],'object_properties':base['object_properties']},
                 'source_mapping':base['source_mappings'],
                 'relation_source_mapping':base.get('relation_source_mappings',{}),'past_observations':history_payload}
        messages=[{'role':'system','content':SYSTEM},{'role':'user','content':json.dumps(payload,ensure_ascii=False)}]
        record=dict(sequence_id=sequence_dir.name,t=t,method=method,run_id=str(run_id),threshold=threshold,
            scope='adapted-model run on PENDING review candidates; not formal performance evaluation',
            visible_input_sha256=hashes,model_seed=None,requested_run_label=str(run_id),
            semantic_effect_audited=False,effect_correct=None,ontology_consistent=None,
            ontology_reasoner='NOT_RUN',implementation='new RDB adaptation; original EvoOnt pipeline not executed',
            implementation_version=IMPLEMENTATION_VERSION)
        response={};proposal=None;candidate=base;errors=[];delta=[]
        try:
            response=transport(messages,max_tokens)
            if isinstance(response,str):response={'content':response,'usage':{}}
            proposal=parse_proposal(response)
            candidate,errors,delta=validate_compile(base,ob,proposal)
            semantic=proposal['semantic_confidence'];structural=0.0 if errors else 1.0
            temporal=1.0 if method.endswith('w/o-Temporal') else temporal_evidence(history,ob,proposal['operations'])
            data=1.0 if all(ob['schema.json'].get(op.get('table'),{}).get('row_count',0)>0 for op in proposal['operations'] if op['op']!='map_alias') else .5
            constraint=structural
            score=(semantic+structural+data+constraint)/4 if method.endswith('w/o-Temporal') else (semantic+structural+temporal+data+constraint)/5
            record.update(evidence={'semantic_uncalibrated':semantic,'structural':structural,'temporal':None if method.endswith('w/o-Temporal') else temporal,
                                    'data':data,'constraint':constraint,'aggregate':score,'reason':proposal.get('reason','')},
                          proposal=proposal,validation_errors=errors)
            if errors:action='ABSTAIN' if method.endswith('w/o-Gate') else 'WAIT'
            elif method.endswith('w/o-Gate'):action='EXTEND' if delta else 'REUSE'
            elif proposal['interpretation']!='supported' or score<threshold:action='WAIT'
            else:action='EXTEND' if delta else 'REUSE'
        except Exception as ex:
            action='FAILURE';record['error_type']=type(ex).__name__;record['raw_api_log_path']=getattr(ex,'raw_api_log_path',None)
            # Omit exception text: transport exceptions may contain authentication details.
        prefix='t'+str(t)
        candidate_ttl=turtle(candidate)
        candidate_check=check_turtle(candidate_ttl)
        record['candidate_rdf_syntax_check']=candidate_check
        if proposal:
            (out/(prefix+'_candidate_ontology.ttl')).write_text(candidate_ttl,encoding='utf-8')
        if action in {'EXTEND','REUSE'} and candidate_check!='PASS':
            action='FAILURE';record['error_type']='CandidateRDFValidationFailure'
        # Commit only after independent RDF parsing succeeded. Invalid candidates are
        # retained separately, while final state remains the last valid semantic base.
        state=copy.deepcopy(candidate if action in {'EXTEND','REUSE'} else base)
        state['observed_schema']=ob['schema.json'];history.append(ob)
        ttl=turtle(state)
        record['rdf_syntax_check']=check_turtle(ttl)
        if record['rdf_syntax_check']!='PASS':
            raise ValueError('Last retained semantic base is not parse-valid; abort rollout')
        (out/(prefix+'_ontology.ttl')).write_text(ttl,encoding='utf-8')
        save(out/(prefix+'_source_mapping.json'),mappings(state))
        if proposal:
            (out/(prefix+'_candidate_delta.ttl')).write_text('\n'.join(['@prefix owl: <http://www.w3.org/2002/07/owl#> .','@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .']+delta)+'\n',encoding='utf-8')
        usage=response.get('usage',{});it=usage.get('input_tokens',usage.get('prompt_tokens'));ot=usage.get('output_tokens',usage.get('completion_tokens'))
        record.update(raw_api_log_path=response.get('raw_log_path',record.get('raw_api_log_path')),action=action,completed=action in {'EXTEND','REUSE'},committed=action=='EXTEND',
            input_tokens=it,output_tokens=ot,api_requests=response.get('api_requests',1),model=response.get('model'),
            usage_available=it is not None and ot is not None,latency_s=time.perf_counter()-start,
            ontology_sha256=hashlib.sha256(ttl.encode()).hexdigest())
        rows.append(record)
        (out/'model_diagnostic_logs.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows),encoding='utf-8')
    return rows

def planned_runs():
    return [dict(method=m,run_id=str(seed),dev_thresholds=[.3,.5,.7],test_threshold='freeze on approved dev')
            for m in sorted(METHODS) for seed in [17,29,43]]
