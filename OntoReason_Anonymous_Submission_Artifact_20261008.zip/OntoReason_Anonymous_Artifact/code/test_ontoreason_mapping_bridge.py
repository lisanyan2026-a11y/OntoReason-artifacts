import sys,unittest,sqlite3
from pathlib import Path
R=Path(__file__).parent;sys.path[:0]=[str(R/'packages_minimal'),str(R/'dynamic')]
from ontoreason_mapping_bridge import inventory_from_state,_compile
from ontoreason_core import materialize
import model_adapted_framework_v3 as m

class ActualSQLiteMappingTests(unittest.TestCase):
 def observed(self,kind,t):
  folder=R/'dynamic/dataset_candidate_v1/observed'/('iswc_'+kind+'_template_0_variant_0')/('t'+str(t))
  return m.read_observation(folder)[0],folder/'snapshot.sqlite'
 def state(self,kind,t=0):
  ob,db=self.observed(kind,t);s=m.initial_state(ob['schema.json']);s['relation_source_mappings']={};return s,ob,db
 def test_actual_class_fact_counts_data_and_fk(self):
  state,ob,db=self.state('NewRelation');inventory=inventory_from_state(state,db)
  con=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)
  expected=sum(con.execute('SELECT COUNT(*) FROM "'+t+'"').fetchone()[0] for t in state['classes']);con.close()
  self.assertEqual(sum(len(materialize(x,db)) for k,x in inventory.items() if k.startswith('class:')),expected)
  self.assertTrue(any(materialize(x,db) for k,x in inventory.items() if k.startswith('data:')))
  self.assertTrue(any(materialize(x,db) for k,x in inventory.items() if k.startswith('object:')))
 def test_rename_stable_property_and_fact_set(self):
  state,_,db0=self.state('Rename');ob,db1=self.observed('Rename',1);renamed=m.mechanical_reuse(state,ob)
  old=inventory_from_state(state,db0);new=inventory_from_state(renamed,db1)
  key=next(k for k,x in old.items() if x['source_provenance'].get('column')=='Name' and x['source_provenance'].get('table')=='conferences')
  self.assertEqual(old[key]['heads'],new[key]['heads']);self.assertEqual(old[key]['identity_policy'],new[key]['identity_policy'])
  self.assertEqual(materialize(old[key],db0),materialize(new[key],db1));self.assertEqual(new[key]['source_provenance']['column'],'Name_display')
 def test_actual_association_class_and_three_role_mappings(self):
  state,_,_=self.state('NewRelation');ob,db=self.observed('NewRelation',1)
  new,errors,_=m.validate_compile(state,ob,dict(operations=[dict(op='add_relation',table='reviews_detail',source_table='persons',target_table='papers')]))
  self.assertFalse(errors);inventory=inventory_from_state(new,db)
  mappings=[x for x in inventory.values() if x['source_provenance'].get('table')=='reviews_detail']
  objects=[x for x in mappings if x['id'].startswith('object:')];self.assertEqual(len(objects),3)
  self.assertTrue(all(len(materialize(x,db))>0 for x in objects));self.assertTrue(any(x['id'].startswith('class:') for x in mappings))
 def test_missing_dependency_rejected(self):
  state,_,_=self.state('DependencyMissing');_,db=self.observed('DependencyMissing',1)
  with self.assertRaisesRegex(ValueError,'Unknown FK target'):inventory_from_state(state,db)
 def test_alias_equivalent_provenance(self):
  state,_,_=self.state('Alias');ob,db=self.observed('Alias',1);state['source_mappings']['symposium']=state['classes']['conferences']
  inv=inventory_from_state(state,db);self.assertTrue(any('symposium' in x['source_provenance'].get('verified_equivalent_aliases',[]) for x in inv.values()))
 def test_strict_unsupported_and_orphan_cases(self):
  cases=[('CREATE TABLE a(x INTEGER);','Missing actual primary key'),
   ('CREATE TABLE b(id INTEGER PRIMARY KEY); CREATE TABLE a(id INTEGER PRIMARY KEY, x INTEGER REFERENCES b(id)); INSERT INTO a VALUES(1,99);','Incomplete referenced records'),
   ('CREATE TABLE b(x INTEGER,y INTEGER,PRIMARY KEY(x,y)); CREATE TABLE a(id INTEGER PRIMARY KEY,x INTEGER,y INTEGER,FOREIGN KEY(x,y) REFERENCES b(x,y));','Unsupported composite FK')]
  for sql,error in cases:
   con=sqlite3.connect(':memory:');con.executescript(sql)
   state=dict(classes={'a':'urn:class:a'},source_mappings={'a':'urn:class:a'},data_properties={},object_properties={})
   with self.assertRaisesRegex(ValueError,error):_compile(state,con)
   con.close()

if __name__=='__main__':unittest.main()
