"""Configure externally installed Java, HermiT and embedding paths."""
from pathlib import Path
import argparse,json
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--java',required=True);ap.add_argument('--hermit',required=True);ap.add_argument('--embedding',required=True);a=ap.parse_args()
for name,key,value in [('java_runtime_lock.json','java',a.java),('hermit_runtime_lock.json','jar',a.hermit),('rigor_runtime_lock.json','snapshot_path',a.embedding)]:
 p=R/name;x=json.loads(p.read_text(encoding='utf-8'));x[key]=value;p.write_text(json.dumps(x,indent=2))
print('Local paths configured; manifest will differ for these local config files. Keep the released archive intact.')
