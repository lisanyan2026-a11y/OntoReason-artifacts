"""Shared physical type contract for compatible O0 and typed mapping realization."""
from build_compatible_o0 import typed_inventory,datatype_bindings,physical_xsd
def datatype_map_for_state(state,snapshot):
    return {iri:binding['datatype'] for iri,binding in datatype_bindings(state,snapshot).items()}
