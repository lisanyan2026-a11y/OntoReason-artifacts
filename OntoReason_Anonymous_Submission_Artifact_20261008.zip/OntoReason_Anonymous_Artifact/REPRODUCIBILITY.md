# Result accounting and limitations

- Ontology review: 50 candidates per method; OntoReason 37 supported / 6 refuted / 7 undetermined, RIGOR 15 / 9 / 26.
- Ontology plus mapping: OntoReason 26 / 14 / 10, RIGOR 0 / 9 / 41. Missing mappings are unauditable, not refuted.
- Non-WAIT action coverage: (15 REUSE + 5 EXTEND) / 64 = 31.25%; it is not Accepted Precision or new-version coverage.
- Calls: 109 versus 550 over the 64-context workload, counting each distinct rebuild once. Usage exists for 109 and 490 calls respectively. Missing usage for 60 RIGOR requests is not zero consumption.
- Recorded input tokens: 342069 versus 799862; output tokens: 29411 versus 757648. Summed task duration: 27.46 versus 316.91 minutes, not parallel wall-clock turnaround.
- Cost estimates are partial response-based reference prices, not gateway invoices. Budget reservation/debit totals are not verified actual expenditure.
- Run IDs 17 and 29 are not API-controlled seeds. Temperature is zero, but remote model stochasticity remains uncontrolled. No significance claim is made for correlated contexts.
- Human review annotations and descriptive aggregation are kept separate from method inputs. Do not train or tune thresholds on this evaluation material and then describe the same results as held-out evaluation.
- ETC raw data are excluded because business-data redistribution permission has not been established. Historical manuscript ablation metrics cannot independently validate the new cross-graph/dependency-group mechanisms.
- Automated sanitization may alter artifact text and hashes. The release manifest authenticates released bytes only; original source/result hashes are historical provenance. Runtime replication is unverified and must receive a new run identifier.
