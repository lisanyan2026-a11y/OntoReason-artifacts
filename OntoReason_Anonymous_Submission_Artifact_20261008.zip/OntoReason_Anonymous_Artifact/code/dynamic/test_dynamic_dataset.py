import collections, hashlib, json, sqlite3, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent/'dataset_candidate_v1'
BASE=Path(__file__).resolve().parents[1]/'data/iswc/snapshot.sqlite'
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def obs(seq,t):return ROOT/'observed'/seq/('t'+str(t))

class DatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest=load(ROOT/'manifest.json');cls.gold=load(ROOT/'gold_private/gold_pending.json')
    def test_counts_and_family_split(self):
        self.assertEqual(len(self.manifest),80);self.assertEqual(len(self.gold),320)
        self.assertEqual(collections.Counter(x['split'] for x in self.manifest),dict(train=48,dev=16,test=16))
        families=collections.defaultdict(set)
        for x in self.manifest:families[x['family_id']].add(x['split'])
        self.assertEqual(len(families),40);self.assertTrue(all(len(x)==1 for x in families.values()))
    def test_t0_matches_frozen_base(self):
        sha=hashlib.sha256(BASE.read_bytes()).hexdigest()
        for x in self.manifest:
            self.assertEqual(hashlib.sha256((obs(x['sequence_id'],0)/'snapshot.sqlite').read_bytes()).hexdigest(),sha)
    def test_no_gold_or_future_paths_under_observed(self):
        for p in (ROOT/'observed').rglob('*.json'):
            s=p.read_text(encoding='utf-8')
            self.assertNotIn('gold_action',s);self.assertNotIn('resolvable_at',s)
            self.assertNotIn('effect_spec',s);self.assertNotIn('gold_private',s)
    def test_all_gold_pending(self):
        self.assertTrue(all(g['review_status']=='PENDING' for g in self.gold))
        self.assertFalse(load(ROOT/'generation_report.json')['official_test_results'])
    def test_delayed_docs_arrive_at_t3(self):
        for x in self.manifest:
            if x['event_type']!='DelayedEvidence':continue
            s=x['sequence_id'];schema=load(obs(s,1)/'schema.json')
            base=load(obs(s,0)/'schema.json');added=set(schema)-set(base)
            self.assertEqual(len(added),1);name=added.pop()
            self.assertNotIn(name,load(obs(s,1)/'documentation.json')['tables'])
            self.assertNotIn(name,load(obs(s,2)/'documentation.json')['tables'])
            self.assertIn(name,load(obs(s,3)/'documentation.json')['tables'])
            self.assertEqual(load(obs(s,1)/'schema.json'),load(obs(s,3)/'schema.json'))
    def test_noise_vanishes_and_new_concept_ready_immediately(self):
        for x in self.manifest:
            s=x['sequence_id'];base=load(obs(s,0)/'schema.json')
            if x['event_type']=='TransientNoise':
                self.assertEqual(len(load(obs(s,1)/'schema.json')),len(base)+1)
                self.assertEqual(load(obs(s,3)/'schema.json'),base)
            elif x['event_type']=='NewConcept':
                added=set(load(obs(s,1)/'schema.json'))-set(base);self.assertEqual(len(added),1)
                self.assertIn(added.pop(),load(obs(s,1)/'documentation.json')['tables'])
                gg=[g for g in self.gold if g['sequence_id']==s and g['t']==1][0]
                self.assertEqual(gg['gold_action'],'EXTEND');self.assertEqual(gg['resolvable_at'],1)
    def test_dependency_absent_then_complete(self):
        for x in self.manifest:
            if x['event_type']!='DependencyMissing':continue
            s=x['sequence_id']
            for t in [1,2,3,4]:
                sch=load(obs(s,t)/'schema.json')
                missing=[fk['references_table'] for v in sch.values() for fk in v['foreign_keys'] if fk['references_table'] not in sch]
                self.assertEqual(len(missing),1 if t<3 else 0)
    def test_integrity_foreign_keys_and_variant_differences(self):
        qa=load(ROOT/'qa_snapshot_checks.json');self.assertEqual(len(qa),400)
        self.assertTrue(all(q['integrity']=='ok' and not q['fk_violations'] for q in qa))
        fam=collections.defaultdict(list)
        for x in self.manifest:fam[x['family_id']].append(x)
        for rr in fam.values():
            a,b=rr
            # Alias/conflict can differ in views/docs; other variants differ in schema.
            sig=lambda x:tuple((obs(x['sequence_id'],1)/n).read_bytes() for n in ['schema.json','views.json','documentation.json'])
            self.assertNotEqual(sig(a),sig(b))

if __name__=='__main__':unittest.main()
