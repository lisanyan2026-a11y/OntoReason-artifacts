# OntoReason anonymous review artifact

This package supports review of the bounded prototype evaluation. It contains first-party experiment code, pinned upstream retrieval instructions, frozen generated outputs, 600 human subquestion judgments, metrics, sanitized call-level resource accounting and figures. It is separate from the original complete archive. No network or paid-model call is needed for the primary offline audit.

## Start with the offline audit

Extract to a short local path (for example `artifact/`) to avoid Windows path-length limits. Use Python 3.11 or later. From the package root run:

```text
python code/audit_offline.py
```

This checks file hashes, 64 decisions (5 EXTEND, 15 REUSE, 44 WAIT), 100 reviewed candidates, 600 subquestions, candidate aggregates and 659 sanitized API rows. It checks the released records rather than independently reproducing the human judgments. It needs only the Python standard library. Figure regeneration requires matplotlib; run `python code/plot_recorded_results.py`.

## What the results establish

The public-derived workload uses 8 controlled ISWC sequences, 4 positions and run labels 17 and 29 (64 correlated contexts). Only template group 4 variant 0 is evaluated. The generator can create a larger candidate pool; generated pool size is not evaluation size. RIGOR has 22 distinct rebuild attempts, 17 completed and 5 failed; 50 contexts have paired retained outputs. Both start with a shared O0, but only OntoReason evolves its accepted parent history. This is not the full official BURR benchmark, an identical-parent transition experiment, or a GNN evaluation.

The candidate-level aggregation is descriptive and post-review; case-level metric approval is false. Unresolved and unauditable items are not semantic failures. Source mappings are not a native RIGOR output. The 600 judgments come from one reviewer, not a fully blinded independent panel. No full-run Accepted Precision or false-extension rate is inferred. ETC ablation figures reproduce earlier manuscript-reported values; no ETC raw business records or event-level ablation replication data are included.

## Regenerate public-derived data and rerun models

Perform these steps in a separate working copy. They require network access, upstream download rights, dependencies, Java/HermiT, an embedding model and a compatible paid API. They have NOT been executed as an end-to-end clean-room rerun of this sanitized package.

1. `python code/fetch_pinned_upstream.py` retrieves BURR and RIGOR at the recorded commits and checks archive SHA-256. Upstream code and source datasets are not redistributed. Review their licenses and dataset terms at the pinned commits before use or redistribution.
2. Install `code/requirements_rigor_locked.txt` in an isolated environment. These are recorded historical versions, not a freshly solved environment. Dependency availability may differ; keep any changed lock under a new run version. HermiT and Java are installed separately; their hashes are recorded in the runtime locks. Download `sentence-transformers/all-MiniLM-L6-v2` at revision `1110a243fdf4706b3f48f1d95db1a4f5529b4d41`.
3. From `code/`, run `python prepare_iswc.py` in a fresh directory. This parses the pinned ISWC SQL into SQLite and refuses to overwrite existing source snapshots. SQLite conversion is part of the adapter, not native PostgreSQL execution.
4. From `code/`, run `python dynamic/generate_iswc_dynamic.py --help`, then supply `--base data/iswc/snapshot.sqlite --out dynamic/dataset_candidate_v1`. Candidate Gold emitted by the generator remains PENDING and must not replace the human review labels. Method runners read observed current/past inputs, not future snapshots or evaluation Gold.
5. From the package root run `python code/configure_runtime.py --java <java-executable> --hermit <hermit-jar> --embedding <embedding-snapshot>`. Never put credentials in these files. Then run `python code/prepare_frozen_seeds.py` to copy the released compatible O0 into the fresh runtime. Its recorded preflight is historical evidence, not a new execution check. Building O0 afresh using `build_compatible_o0.py` additionally requires the original review-seed placement; do not assume that route is a one-command reproduction.
6. Set `ONTOREASON_API_URL` locally to an Anthropic-compatible endpoint. The original private gateway and proxy are removed. The API token is read from stdin by the runners; enter or supply it locally without saving it in files or shell history. Read the budget settings before any run. Run the RIGOR adapter first (`run_rigor_parallel_shared_v2.py`), and the core runner (`run_core_shared_o0_v2.py --parallel-authorized`) from `code/` only after validating the frozen input hashes. The flag bypasses the original execution barrier; it does not grant any external authorization or verify baseline completion. Reruns must go into fresh runtime folders. Provider billing, retry behavior, model availability and exact outputs can differ.

## Portability and attribution

The released first-party scripts have local path, proxy and endpoint edits. SANITIZATION_CHANGES.json retains original and release hashes for changed files. Frozen run records contain original code hashes; these are provenance of the measured run, not the sanitized-source hashes. Source snapshots, API payloads and environment installations are excluded. Full artifact regeneration and all model outputs are therefore not independently verified from this package. The offline results audit is the tested entry point.

Original third-party project attribution in public repository URLs and version locks is preserved; it is not submission-author identity. No blanket license is granted over third-party material. First-party material is supplied for review; no new unrestricted reuse license is asserted here.

See REPRODUCIBILITY.md for metric denominators, EXCLUSIONS.json for omitted content, and PRIVACY_SCAN.json for automated checks. Local source paths are removed, and no access-monitoring mechanism is bundled. Hosting anonymity and access logging must also be checked before publishing a review link.
