"""Real deterministic rule baseline on observed snapshots only; NOT EvoOnt/RIGOR.

No gold access, no semantic effect audit, no OWL reasoner, no formal metrics.
"""
import argparse, copy, hashlib, json, time
from pathlib import Path
from urllib.parse import quote

NS='https://example.org/iswc-rule/'
def uri(kind,name):return NS+kind+'/'+quote(name,safe='')
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')

def initial_state(schema):
    state={'classes':{},'data_properties':{},'object_properties':{},'source_mappings':{},'observed_schema':schema}
    for table,spec in schema.items():
        cu=uri('class',table);state['classes'][table]=cu;state['source_mappings'][table]=cu
        for column in spec['columns']:
            key=table+'.'+column;state['data_properties'][key]={'uri':uri('data',key),'domain':cu}
    for table,spec in schema.items():
        for fk in spec['foreign_keys']:
            key=table+'.'+fk['column'];state['object_properties'][key]={'uri':uri('object',key),
                'domain':state['classes'][table],'range':state['classes'].get(fk['references_table'])}
    return state

def read_observation(folder):
    # Explicit allowlist; no recursive traversal, manifests or gold/private reads.
    names=['schema.json','documentation.json','event.json','views.json']
    obj={n:load(folder/n) for n in names}
    hashes={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in names}
    if any(k in json.dumps(obj) for k in ['gold_action','effect_spec','resolvable_at','gold_private']):
        raise ValueError('Oracle fields found in model observation')
    return obj,hashes

def step(state,observation):
    schema=observation['schema.json'];docs=observation['documentation.json'];event=observation['event.json']
    views=observation['views.json'];old=state['observed_schema'];new=copy.deepcopy(state)
    new['observed_schema']=schema
    missing=[table+'.'+fk['column']+' -> '+fk['references_table'] for table,spec in schema.items()
             for fk in spec['foreign_keys'] if fk['references_table'] not in schema]
    if missing:return new,'WAIT',{'dependency_missing':missing},[]
    if docs.get('proposed_claim',{}).get('status')=='unresolved proposal':
        return new,'WAIT',{'unresolved_semantic_proposal':docs['proposed_claim']['claim']},[]
    changes=[]; evidence={'schema_delta':{'added_tables':sorted(set(schema)-set(old)),'removed_tables':sorted(set(old)-set(schema))}}
    if event.get('change')=='table_renamed':
        a,b=event['before'],event['after']
        if a in new['classes'] and b in schema:
            cu=new['classes'].pop(a);new['classes'][b]=cu;new['source_mappings'][b]=cu
            new['source_mappings'].pop(a,None)
            for key in list(new['data_properties']):
                if key.startswith(a+'.'):new['data_properties'][b+key[len(a):]]=new['data_properties'].pop(key)
            evidence['rename_mapping_preserved']=True
    if event.get('change')=='column_renamed':
        table=event['table'];a=table+'.'+event['before'];b=table+'.'+event['after']
        if a in new['data_properties']:
            new['data_properties'][b]=new['data_properties'].pop(a);evidence['rename_mapping_preserved']=True
    new_tables=[t for t in schema if t not in new['source_mappings']]
    unsupported=[t for t in new_tables if t not in docs.get('tables',{}) or
                 any(x in docs.get('tables',{}).get(t,'').lower() for x in ['unverified','not been established','unavailable'])]
    if unsupported:return new,'WAIT',dict(evidence,unsupported_table_meaning=unsupported),[]
    for table in new_tables:
        spec=schema[table];fks=spec['foreign_keys']
        relation= len(fks)==2 and {'source_id','target_id'}.issubset(spec['columns'])
        if relation:
            source=next(f for f in fks if f['column']=='source_id');target=next(f for f in fks if f['column']=='target_id')
            # New target classes are installed in a separate pass below.
            new['source_mappings'][table]=uri('object',table)
        else:
            cu=uri('class',table);new['classes'][table]=cu;new['source_mappings'][table]=cu
            changes.append({'kind':'class','table':table,'uri':cu})
            for col in spec['columns']:
                key=table+'.'+col;new['data_properties'][key]={'uri':uri('data',key),'domain':cu}
                changes.append({'kind':'data_property','source_column':key})
    for table in new_tables:
        spec=schema[table];fks=spec['foreign_keys']
        if len(fks)==2 and {'source_id','target_id'}.issubset(spec['columns']):
            source=next(f for f in fks if f['column']=='source_id');target=next(f for f in fks if f['column']=='target_id')
            new['object_properties'][table]={'uri':uri('object',table),'domain':new['classes'].get(source['references_table']),
                                           'range':new['classes'].get(target['references_table'])}
            changes.append({'kind':'object_property','source_table':table})
        else:
            for fk in fks:
                key=table+'.'+fk['column'];new['object_properties'][key]={'uri':uri('object',key),
                    'domain':new['classes'][table],'range':new['classes'].get(fk['references_table'])}
                changes.append({'kind':'foreign_key_property','source_column':key})
    for alias,target in docs.get('aliases',{}).items():
        if alias in views and target in new['source_mappings']:
            new['source_mappings'][alias]=new['source_mappings'][target];evidence['alias_mapping']=dict(alias=alias,target=target)
    invalid=[k for k,v in new['object_properties'].items() if not v['domain'] or not v['range']]
    if invalid:return dict(state,observed_schema=schema),'WAIT',dict(evidence,missing_mapped_endpoints=invalid),[]
    return new,('EXTEND' if changes else 'REUSE'),evidence,changes

def turtle(state):
    lines=['@prefix owl: <http://www.w3.org/2002/07/owl#> .','@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .']
    for cu in sorted(set(state['classes'].values())):lines.append('<'+cu+'> a owl:Class .')
    for v in state['data_properties'].values():
        lines.append('<'+v['uri']+'> a owl:DatatypeProperty ; rdfs:domain <'+v['domain']+'> .')
    for v in state['object_properties'].values():
        if v['domain'] and v['range']:
            lines.append('<'+v['uri']+'> a owl:ObjectProperty ; rdfs:domain <'+v['domain']+'> ; rdfs:range <'+v['range']+'> .')
    # Turtle prefixes must precede their use; do not sort declarations after triples.
    return '\n'.join(lines[:2]+sorted(set(lines[2:])))+'\n'

def run(observed,out):
    if out.exists() and any(out.iterdir()):raise ValueError('Fresh diagnostic output required')
    out.mkdir(parents=True,exist_ok=True);logs=[]
    for seqdir in sorted(p for p in observed.iterdir() if p.is_dir()):
        initial,_=read_observation(seqdir/'t0');state=initial_state(initial['schema.json'])
        dest=out/seqdir.name;dest.mkdir();save(dest/'t0_state.json',state)
        (dest/'t0_ontology.ttl').write_text(turtle(state),encoding='utf-8')
        for t in range(1,5):
            started=time.perf_counter();ob,hashes=read_observation(seqdir/('t'+str(t)))
            next_state,action,evidence,delta=step(state,ob)
            # WAIT retains semantic state, while observation history advances.
            if action=='WAIT':next_state=dict(state,observed_schema=ob['schema.json'])
            state=next_state;ttl=turtle(state)
            (dest/('t'+str(t)+'_ontology.ttl')).write_text(ttl,encoding='utf-8')
            save(dest/('t'+str(t)+'_state.json'),state)
            logs.append(dict(sequence_id=seqdir.name,t=t,method='Rule-based Evolution diagnostic',
                scope='pending-gold diagnostic, not formal evaluated result',action=action,
                completed=action in {'REUSE','EXTEND'},committed=action=='EXTEND',
                effect_correct=None,semantic_effect_audited=False,ontology_consistent=None,
                ontology_consistency_checker='NOT_RUN',constraint_checks={'declared_fk_endpoints_present':not evidence.get('dependency_missing'),
                'mapped_property_endpoints_present':not evidence.get('missing_mapped_endpoints')},
                evidence=evidence,committed_delta=delta,visible_input_sha256=hashes,
                input_tokens=0,output_tokens=0,api_requests=0,latency_s=time.perf_counter()-started,
                ontology_sha256=hashlib.sha256(ttl.encode()).hexdigest()))
    (out/'diagnostic_logs.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in logs),encoding='utf-8')
    from collections import Counter
    summary=dict(n_decisions=len(logs),action_counts=dict(Counter(r['action'] for r in logs)),
        external_model_calls=0,formal_metrics_generated=False,
        limitations=['No semantic gold audit or OWL reasoner','Pending human-reviewed data and O0',
        'Direct table-class O0 differs from official ontology gold','Rules rely on current supplied documentation',
        'No delete/retype or learned structural evidence; no performance comparison to four required methods'])
    save(out/'diagnostic_report.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--observed',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();run(args.observed,args.out)
