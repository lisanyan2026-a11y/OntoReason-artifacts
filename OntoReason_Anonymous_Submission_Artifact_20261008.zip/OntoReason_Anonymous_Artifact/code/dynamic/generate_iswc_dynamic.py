"""ISWC-based controlled evolution CANDIDATES, all gold PENDING human review.

No model is called and no method performance is generated. Five disjoint templates
per event type, two schema/data variants per template, split by template family.
"""
import argparse, collections, csv, hashlib, json, shutil, sqlite3
from pathlib import Path

TYPES=['Rename','Alias','NewConcept','NewRelation','TransientNoise','ConflictingChange','DelayedEvidence','DependencyMissing']
BASE_TARGETS=[('conferences','ConfID','Name'),('organizations','OrgID','Name'),
              ('papers','PaperID','Title'),('persons','PerID','LastName'),('topics','TopicID','TopicName')]
CONCEPTS=['research_awards','research_datasets','funding_grants','software_artifacts','review_reports']
RELATIONS=[('persons','PerID','papers','PaperID','reviews'),
           ('organizations','OrgID','conferences','ConfID','sponsors'),
           ('papers','PaperID','papers','PaperID','cites'),
           ('persons','PerID','conferences','ConfID','chairs'),
           ('topics','TopicID','topics','TopicID','related_topics')]

def write_json(p,data):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def quoted(s):return '"'+s.replace('"','""')+'"'

def inspect(c):
    out={}
    for (t,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").fetchall():
        cols={r[1]:dict(type=r[2],primary_key=bool(r[5]),nullable=not(r[3] or r[5]))
              for r in c.execute('PRAGMA table_info('+quoted(t)+')')}
        fks=[dict(column=r[3],references_table=r[2],references_column=r[4])
             for r in c.execute('PRAGMA foreign_key_list('+quoted(t)+')')]
        out[t]=dict(columns=cols,foreign_keys=fks,row_count=c.execute('SELECT count(*) FROM '+quoted(t)).fetchone()[0])
    return out

def baseline_docs(schema):
    return {'domain':'ISWC research conferences and publications',
            'tables':{t:'Existing source table '+t+'; retain its established meaning.' for t in schema},
            'resource_policy':'Only this snapshot and past observations are visible. No gold or future snapshots.'}

def positive_ids(c,t,pk,n):
    return [r[0] for r in c.execute('SELECT '+quoted(pk)+' FROM '+quoted(t)+' ORDER BY '+quoted(pk)+' LIMIT ?', (n,))]

def mutate(c,kind,k,v,t,docs):
    """Return current visible event and evaluator-private required effect spec."""
    table,pk,col=BASE_TARGETS[k]; suffix='_detail' if v==0 else '_record'
    name=CONCEPTS[k]+suffix; n=2+v
    event={'change':'none','source_objects':[]}
    target={'event_type':kind,'template_index':k,'variant':v,'target_table':table}
    if t==0:return event,target
    if kind=='Rename':
        if v==0:
            renamed=col+'_display';c.execute('ALTER TABLE '+quoted(table)+' RENAME COLUMN '+quoted(col)+' TO '+quoted(renamed))
            event=dict(change='column_renamed',table=table,before=col,after=renamed)
            docs['tables'][table]='Column '+renamed+' is the former '+col+'; the referent and values are unchanged.'
            target.update(effect='reuse_existing_property_update_source_mapping',old_column=col,new_column=renamed)
        else:
            renamed=table+'_catalog';c.execute('ALTER TABLE '+quoted(table)+' RENAME TO '+quoted(renamed))
            event=dict(change='table_renamed',before=table,after=renamed)
            docs['tables'].pop(table);docs['tables'][renamed]='Former '+table+' table; same business referent and records.'
            target.update(effect='reuse_existing_class_update_source_mapping',old_table=table,new_table=renamed)
    elif kind=='Alias':
        alias=['symposium','research_institute','article','researcher','subject_area'][k]
        alias=alias if v==0 else alias+'_catalog'
        # Alias view is a distinct SQL structure, with no new stored business entities.
        c.execute('CREATE VIEW '+quoted(alias)+' AS SELECT * FROM '+quoted(table))
        docs['aliases']={alias:table}; docs['tables'][table]='Alias '+alias+' refers to these same '+table+' records.'
        event=dict(change='alias_view_added',view=alias,source_table=table)
        target.update(effect='reuse_existing_class_allow_alias_mapping',alias=alias)
    elif kind in {'NewConcept','DelayedEvidence'}:
        fields='id INTEGER PRIMARY KEY,label TEXT NOT NULL,'+quoted(pk)+' INTEGER NOT NULL REFERENCES '+quoted(table)+'('+quoted(pk)+')'
        fields+=',status TEXT CHECK(status IN (\'active\',\'archived\'))' if v else ',created_year INTEGER CHECK(created_year>=1900)'
        c.execute('CREATE TABLE '+quoted(name)+'('+fields+')')
        ids=positive_ids(c,table,pk,n)
        for i,x in enumerate(ids):
            extra='active' if v else 2020+i
            c.execute('INSERT INTO '+quoted(name)+' VALUES(?,?,?,?)',(i+1,'Record '+str(i+1),x,extra))
        event=dict(change='table_added',table=name)
        if kind=='NewConcept' or t>=3:
            docs['tables'][name]='Independent '+CONCEPTS[k].replace('_',' ')+' business entities with their own identity and lifecycle; each is linked to '+table+'. Not an alias or staging artifact.'
        target.update(effect='add_class_and_source_mapping',new_table=name,required_identity_column='id')
    elif kind=='NewRelation':
        st,sp,tt,tp,predicate=RELATIONS[k];name=predicate+suffix
        c.execute('CREATE TABLE '+quoted(name)+'(source_id INTEGER NOT NULL REFERENCES '+quoted(st)+'('+quoted(sp)+'),target_id INTEGER NOT NULL REFERENCES '+quoted(tt)+'('+quoted(tp)+'),'+
                  ('role TEXT NOT NULL,' if v else 'since_year INTEGER,')+'PRIMARY KEY(source_id,target_id))')
        aa,bb=positive_ids(c,st,sp,n),positive_ids(c,tt,tp,n+1)
        for i,(a,b) in enumerate(zip(aa,bb[1:] if st==tt else bb)):
            c.execute('INSERT INTO '+quoted(name)+' VALUES(?,?,?)',(a,b,'lead' if v else 2020+i))
        docs['tables'][name]='New directed business relation: '+st+' '+predicate+' '+tt+'. Source and target are existing entities; intermediary rows represent this relation.'
        event=dict(change='relation_table_added',table=name,source=st,target=tt)
        target.update(effect='add_object_property_and_source_mapping',new_table=name,source_table=st,target_table=tt,predicate=predicate)
    elif kind=='TransientNoise':
        name='staging_'+table+suffix
        if t<3:
            c.execute('CREATE TABLE '+quoted(name)+'(batch_id INTEGER PRIMARY KEY,payload TEXT,checksum TEXT'+(',attempt INTEGER CHECK(attempt>=0)' if v else '')+')')
            for i in range(n):
                vals=(i+1,'temporary export','checksum-'+str(i)) + ((i,) if v else ())
                c.execute('INSERT INTO '+quoted(name)+' VALUES('+','.join('?' for _ in vals)+')',vals)
            docs['tables'][name]='Unverified import staging records; business interpretation has not been established.'
            event=dict(change='staging_table_added',table=name)
        else:event=dict(change='staging_table_absent',table=name)
        target.update(effect='no_semantic_extension',temporary_table=name)
    elif kind=='ConflictingChange':
        claim=('class '+table+' is disjoint with itself, although its existing instances remain valid' if v==0
               else 'the mandatory identity '+table+'.'+pk+' must simultaneously be absent and present on every record')
        docs['proposed_claim']={'claim':claim,'status':'unresolved proposal','source':'incoming domain memorandum'}
        # Preserve loaded DB; conflict is a semantic proposal, not corrupt SQL.
        event=dict(change='conflicting_documentation_received',table=table)
        target.update(effect='do_not_commit_inconsistent_axiom',conflicting_claim=claim)
    elif kind=='DependencyMissing':
        missing='dependency_'+CONCEPTS[k]+suffix;link='links_'+CONCEPTS[k]+suffix
        c.execute('CREATE TABLE '+quoted(link)+'(source_id INTEGER NOT NULL REFERENCES '+quoted(table)+'('+quoted(pk)+'),target_id INTEGER NOT NULL REFERENCES '+quoted(missing)+'(id),PRIMARY KEY(source_id,target_id))')
        if t>=3:
            c.execute('CREATE TABLE '+quoted(missing)+'(id INTEGER PRIMARY KEY,label TEXT NOT NULL'+(',code TEXT UNIQUE' if v else ',kind TEXT')+')')
            for i,x in enumerate(positive_ids(c,table,pk,n)):
                c.execute('INSERT INTO '+quoted(missing)+' VALUES(?,?,?)',(i+1,'Target '+str(i+1),str(i+1) if v else 'research_resource'))
                c.execute('INSERT INTO '+quoted(link)+' VALUES(?,?)',(x,i+1))
            docs['tables'][missing]='Verified independent target entity with unique identity.'
            docs['tables'][link]='Verified directed relation from '+table+' to '+missing+'; both endpoint mappings are now available.'
        else:
            # Deliberately unresolved FK declaration. Empty rows avoid inventing target data.
            docs['tables'][link]='A relation proposal whose target definition and records are unavailable.'
        event=dict(change='dependency_relation_observed',table=link,declared_target=missing)
        target.update(effect='add_target_class_and_relation_atomically',new_table=missing,relation_table=link)
    return event,target

def snapshot(base,folder,kind,k,v,t):
    folder.mkdir(parents=True,exist_ok=True);db=folder/'snapshot.sqlite';shutil.copy2(base,db)
    c=sqlite3.connect(db);c.execute('PRAGMA foreign_keys=ON')
    before=inspect(c);docs=baseline_docs(before)
    event,target=mutate(c,kind,k,v,t,docs);c.commit()
    schema=inspect(c)
    views={name:sql for name,sql in c.execute("SELECT name,sql FROM sqlite_master WHERE type='view'")}
    try:violations=c.execute('PRAGMA foreign_key_check').fetchall();fk_error=None
    except sqlite3.OperationalError as ex:violations=[];fk_error=str(ex)
    integrity=c.execute('PRAGMA integrity_check').fetchone()[0]
    sql='\n'.join(row[0]+';' for row in c.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name"))
    c.close();write_json(folder/'schema.json',schema)
    write_json(folder/'documentation.json',docs);write_json(folder/'event.json',event)
    write_json(folder/'views.json',views);(folder/'schema.sql').write_text(sql,encoding='utf-8')
    return target,dict(t=t,integrity=integrity,fk_violations=violations,fk_error=fk_error,
                       tables=len(schema),columns=sum(len(x['columns']) for x in schema.values()),
                       views=len(views),hashes={p.name:digest(p) for p in folder.iterdir() if p.is_file()})

def main():
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    if a.out.exists() and any(a.out.iterdir()):raise ValueError('Refuse overwriting existing dataset; use fresh output directory')
    a.out.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect('file:'+a.base.resolve().as_posix()+'?mode=ro',uri=True)
    baseline=inspect(c);base_fk=c.execute('PRAGMA foreign_key_check').fetchall();c.close()
    if base_fk:raise ValueError('Baseline has FK violations; repair protocol required before generation')
    manifest=[];gold=[];review=[];qa=[]
    for kind in TYPES:
        for k in range(5):
            split='train' if k<3 else ('dev' if k==3 else 'test')
            family=kind+'_template_'+str(k)
            for v in range(2):
                seq='iswc_'+family+'_variant_'+str(v);detail=[];effect=None
                for t in range(5):
                    target,result=snapshot(a.base,a.out/'observed'/seq/('t'+str(t)),kind,k,v,t)
                    if t:effect=target
                    if result['integrity']!='ok':raise ValueError('Invalid SQLite integrity')
                    missing_expected=kind=='DependencyMissing' and 0<t<3
                    if result['fk_violations'] or (result['fk_error'] and not missing_expected):
                        raise ValueError('Unexpected FK violation '+seq+' '+str(result))
                    result.update(sequence_id=seq,expected_missing_dependency=missing_expected);detail.append(result)
                qa.extend(detail)
                extending=kind in {'NewConcept','NewRelation','DelayedEvidence','DependencyMissing'}
                ready=3 if kind in {'DelayedEvidence','DependencyMissing'} else (1 if extending else None)
                for t in range(1,5):
                    action='REUSE'
                    if kind=='ConflictingChange' or (kind=='TransientNoise' and t<3):action='WAIT'
                    elif extending:action='WAIT' if t<ready else ('EXTEND' if t==ready else 'REUSE')
                    gold.append(dict(sequence_id=seq,event_id=seq+'_event',family_id=family,t=t,split=split,
                        gold_action=action,requires_extension=extending,resolvable_at=ready,
                        review_status='PENDING',effect_spec=effect,
                        forbidden_effects=['duplicate_existing_business_concept','inconsistent_axiom','dangling_relation_endpoint'],
                        allowed_reuse_edits=['source_mapping','alias_annotation']))
                manifest.append(dict(sequence_id=seq,family_id=family,template_index=k,variant=v,event_type=kind,
                    split=split,status='PENDING_REVIEW_NOT_FORMAL_TEST',source_base_sha256=digest(a.base),
                    data_kind='controlled_synthetic_evolution_over_official_iswc',n_snapshots=5))
                review.append(dict(sequence_id=seq,family_id=family,event_type=kind,split=split,reviewer_A='',reviewer_B='',
                                   reviewer_A_decision='',reviewer_B_decision='',adjudicator='',review_status='PENDING',notes=''))
    write_json(a.out/'manifest.json',manifest);write_json(a.out/'gold_private/gold_pending.json',gold)
    write_json(a.out/'qa_snapshot_checks.json',qa)
    with (a.out/'gold_private/review_checklist.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(review[0]));w.writeheader();w.writerows(review)
    summary=dict(n_sequences=len(manifest),n_snapshots=len(qa),n_decisions=len(gold),n_template_families=40,
                 split_sequences=dict(collections.Counter(x['split'] for x in manifest)),
                 event_types=dict(collections.Counter(x['event_type'] for x in manifest)),
                 official_test_results=False,all_gold_review='PENDING',
                 baseline_tables=len(baseline),baseline_sha256=digest(a.base),
                 exception='DependencyMissing t1/t2 intentionally declares an absent target table; no dangling rows inserted.',
                 limitation='Generated template families are an engineering candidate pool; semantic independence and gold require dual human review. They are not natural historical events.')
    write_json(a.out/'generation_report.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
