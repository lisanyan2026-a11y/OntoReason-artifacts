import inspect,unittest
import run_rigor_dynamic_burr as r
from anthropic_transport import Transport

class RigorDynamicTests(unittest.TestCase):
 def test_exact_context_cache_boundaries(self):
  plan=r.contexts();self.assertEqual(len(plan),8);self.assertEqual(sum(len(x['contexts']) for x in plan),11)
  self.assertEqual(sum(len(c['times']) for x in plan for c in x['contexts']),32)
  delayed=next(x for x in plan if '_DelayedEvidence_' in x['sequence_id'])
  self.assertEqual([c['times'] for c in delayed['contexts']],[[1,2],[3,4]])
  self.assertEqual(delayed['contexts'][0]['hashes']['schema'],delayed['contexts'][1]['hashes']['schema'])
  self.assertNotEqual(delayed['contexts'][0]['hashes']['documentation'],delayed['contexts'][1]['hashes']['documentation'])
 def test_source_constraint_preservation(self):
  plan=r.contexts()
  for seq in plan:
   for context in seq['contexts']:
    schema=r.load(r.Path(context['observation'])/'schema.json');converted=r.schema_for_official(schema)
    for t in schema:
     self.assertEqual(converted[t]['columns'],schema[t]['columns']);self.assertEqual(converted[t]['foreign_keys'],schema[t].get('foreign_keys',[]))
 def test_default_transport_cap_unchanged(self):
  self.assertEqual(inspect.signature(Transport.__init__).parameters['budget_limit'].default,100)

if __name__=='__main__':unittest.main()
