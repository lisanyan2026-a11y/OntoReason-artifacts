"""Anthropic-compatible transport with raw artifacts and conservative USD budget ledger."""
import hashlib,json,time,urllib.request,urllib.error,threading,contextlib,os
from pathlib import Path
class BudgetExceeded(RuntimeError):pass
@contextlib.contextmanager
def ledger_guard(root):
    """Cross-process reservation lock; network requests run outside this lock."""
    path=Path(root)/'budget.lock'
    with path.open('a+b') as f:
        f.seek(0,2)
        if f.tell()==0:f.write(b'0');f.flush()
        deadline=time.monotonic()+60
        while True:
            try:
                f.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic()>deadline:raise TimeoutError('Shared budget lock timeout')
                time.sleep(.05)
        try:yield
        finally:
            f.seek(0)
            if os.name=='nt':msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(f,fcntl.LOCK_UN)
class Transport:
    def __init__(self,token,root,model='claude-sonnet-4-6',budget_limit=100):
        self._token=token;self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
        self.model=model;self.budget_limit=budget_limit;self.lock=threading.Lock();self.local=threading.local()
        self.opener=urllib.request.build_opener()
    @property
    def last_response(self):return self.local.last_response
    @property
    def last_call_dir(self):return self.local.last_call_dir
    def __call__(self,messages,max_tokens=4096,system='',tag='call'):
        return self._call(messages,max_tokens,system,tag)
    def _call(self,messages,max_tokens,system,tag):
        payload={'model':self.model,'max_tokens':min(max_tokens,4096),'temperature':0,'thinking':{'type':'disabled'},'messages':messages}
        if system:payload['system']=system
        data=json.dumps(payload,ensure_ascii=False).encode('utf-8')
        with self.lock,ledger_guard(self.root):
            ledger=self.root/'ledger.jsonl'
            old=[json.loads(x) for x in ledger.read_text(encoding='utf-8').splitlines()] if ledger.exists() else []
            spent=0
            for row in old:
                prior=self.root/f"{row['call_id']:05d}_{row['tag']}"/'call_record.json'
                settled=json.loads(prior.read_text(encoding='utf-8')) if prior.exists() else row
                spent+=settled['budget_debit_usd']
            # Each UTF-8 byte plus 2048 protocol tokens is a conservative prompt bound.
            # Twice official Sonnet4.6 standard prices; no cache discounts assumed.
            reserve=((len(data)+2048)*6+payload['max_tokens']*30)/1e6
            if spent+reserve>self.budget_limit:raise BudgetExceeded('Conservative shared ledger limit reached')
            i=len(old)+1;out=self.root/f'{i:05d}_{tag}';out.mkdir()
            (out/'request.json').write_bytes(data)
            start=time.perf_counter();record={'call_id':i,'tag':tag,'model_requested':self.model,'budget_debit_usd':reserve,'budget_kind':'reserved upper bound; not provider invoice','input_bound_tokens':len(data)+2048,'output_bound_tokens':payload['max_tokens'],'status':'RESERVED','prior_debit_usd':spent}
            # Reserve before sending; interruption leaves full reserve charged.
            with ledger.open('a',encoding='utf-8') as f:f.write(json.dumps(record)+'\n')
        self.local.last_call_dir=out
        request=urllib.request.Request(os.environ['ONTOREASON_API_URL'],data=data,headers={'Content-Type':'application/json','Authorization':'Bearer '+self._token,'x-api-key':self._token,'anthropic-version':'2023-06-01','User-Agent':'EvoOnt-experiment/1.0'},method='POST')
        try:
            with self.opener.open(request,timeout=180) as r:result=json.load(r)
            (out/'response.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
            self.local.last_response=result;self.local.last_call_dir=out
            record.update(status='SUCCESS',usage=result.get('usage',{}),model_returned=result.get('model'),latency_s=time.perf_counter()-start,stop_reason=result.get('stop_reason'))
            text='\n'.join(b.get('text','') for b in result.get('content',[]) if b.get('type')=='text')
            usage=result.get('usage',{})
            if all(type(usage.get(k)) is int for k in ['input_tokens','output_tokens']):
                record['official_reference_estimate_usd']=(usage['input_tokens']*3+usage.get('cache_creation_input_tokens',0)*6+usage.get('cache_read_input_tokens',0)*3+usage['output_tokens']*15)/1e6
                record['budget_debit_usd']=record['official_reference_estimate_usd']*2
                record['budget_kind']='2x conservative official reference estimate; not gateway invoice'
            if not text:
                record['status']='NO_TEXT_CONTENT'
                raise RuntimeError('No text content in response')
            return text
        except urllib.error.HTTPError as e:
            record.update(status='HTTP_ERROR',http_status=e.code,latency_s=time.perf_counter()-start)
            raise RuntimeError(f'Gateway HTTP {e.code}; response body omitted') from None
        except Exception as e:
            if record['status']=='RESERVED':record.update(status='ERROR',error_type=type(e).__name__,latency_s=time.perf_counter()-start)
            raise
        finally:
            with self.lock,ledger_guard(self.root):(out/'call_record.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
