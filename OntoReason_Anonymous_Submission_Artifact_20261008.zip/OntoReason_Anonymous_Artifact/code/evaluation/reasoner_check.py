"""Actual independent HermiT consistency check; errors/unsupported constructs stay UNKNOWN."""
import argparse,hashlib,json,subprocess,sys,time
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'packages_minimal'))
from rdflib import Graph,OWL
def check(path,out):
    path=Path(path);out=Path(out);out.mkdir(parents=True,exist_ok=True)
    java=json.loads((R/'java_runtime_lock.json').read_text())['java'];lock=json.loads((R/'hermit_runtime_lock.json').read_text());jar=lock['jar']
    record={'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'reasoner_jar_sha256':lock['jar_sha256'],'scope':'post-hoc OWL logical consistency only; not semantic correctness or online Gate evidence','ontology_consistent':None,'status':'UNKNOWN'}
    start=time.perf_counter()
    try:
        g=Graph().parse(path)
        imports=list(g.objects(None,OWL.imports))
        if imports:raise RuntimeError('External ontology imports are not frozen; refusing remote imports')
        rdfxml=out/'reasoner_input.owl';g.serialize(rdfxml,format='xml')
        result=subprocess.run([java,'-Xmx1024M','-jar',jar,'--consistency',rdfxml.resolve().as_uri()],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
        (out/'stdout.txt').write_text(result.stdout,encoding='utf-8');(out/'stderr.txt').write_text(result.stderr,encoding='utf-8')
        record['exit_code']=result.returncode
        text=result.stdout+'\n'+result.stderr
        if 'org.semanticweb.owlapi.reasoner.InconsistentOntologyException: Inconsistent ontology' in text:
            record.update(status='INCONSISTENT',ontology_consistent=False)
        if result.returncode==0 and not any(x in text for x in ['Exception','Unsupported','unsupported','ERROR']):
            if 'http://www.w3.org/2002/07/owl#Thing is satisfiable.' in text:record.update(status='CONSISTENT',ontology_consistent=True)
            elif 'http://www.w3.org/2002/07/owl#Thing is not satisfiable.' in text or 'http://www.w3.org/2002/07/owl#Thing is unsatisfiable.' in text:record.update(status='INCONSISTENT',ontology_consistent=False)
    except Exception as e:record['error_type']=type(e).__name__;record['error']=str(e)[:300]
    record['latency_s']=time.perf_counter()-start;(out/'reasoner_result.json').write_text(json.dumps(record,indent=2),encoding='utf-8');return record
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--ontology',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();print(json.dumps(check(a.ontology,a.out)))
