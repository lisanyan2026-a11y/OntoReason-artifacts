"""Pinned official RIGOR full rebuild with fixed shared O0 and exact-input cache.
No native evolution, source mapping output or action labels are invented.
"""
import argparse,contextlib,hashlib,importlib.util,json,os,random,sys,time
from pathlib import Path
R=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def schema_for_official(raw):
 # Preserve explicit column PK/nullable/unique/type and FK declarations. Official
 # loader may perform its documented inference/cleaning; source JSON is retained.
 return {t:dict(columns=v['columns'],foreign_keys=v.get('foreign_keys',[])) for t,v in raw.items()}
def contexts():
 manifest=load(R/'dynamic/dataset_candidate_v1/manifest.json')
 selected=[m for m in manifest if m['split']=='test' and m['template_index']==4 and m['variant']==0]
 result=[]
 for meta in selected:
  seq=meta['sequence_id'];o0=R/'dynamic/independent_review_bundles_v3'/seq/'O0_for_review.ttl'
  unique={}
  for t in range(1,5):
   obs=R/'dynamic/dataset_candidate_v1/observed'/seq/f't{t}'
   # Exact raw current schema/docs and common O0; no future event/human labels.
   hashes=dict(schema=digest(obs/'schema.json'),documentation=digest(obs/'documentation.json'),O0=digest(o0))
   key=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest()
   unique.setdefault(key,dict(context_sha256=key,hashes=hashes,first_t=t,times=[],observation=str(obs),o0=str(o0)))['times'].append(t)
  result.append(dict(sequence_id=seq,contexts=list(unique.values())))
 return result
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--after-v3',action='store_true');ap.add_argument('--plan-only',action='store_true');ap.add_argument('--resume',action='store_true');a=ap.parse_args()
 plan=contexts();n=sum(len(x['contexts']) for x in plan)
 if a.plan_only:
  print(json.dumps(dict(sequences=len(plan),unique_per_run=n,runs=[17,29],actual_rebuilds=n*2,step_provenance=64,plan=plan),indent=2));return
 token=sys.stdin.readline().strip()
 if not token:raise ValueError('Credential must be supplied on stdin; never stored')
 if a.after_v3:
  while not Path('runtime/runs/dyn_v3/completion.json').exists():
   print('Waiting for v3 completion before shared API ledger use',flush=True);time.sleep(30)
 else:assert Path('runtime/runs/dyn_v3/completion.json').exists(),'Use --after-v3; concurrent processes cannot share ledger safely'
 os.environ['HF_HOME']=str(R/'hf_cache');os.environ['HF_HUB_OFFLINE']='1'
 sys.path[:0]=[os.environ.get('EVOONT_RIGOR_PACKAGES','runtime/local_dependency'),str(R/'packages_minimal')]
 from anthropic_transport import Transport,BudgetExceeded
 transport=Transport(token,R/'runs/api_calls',budget_limit=150)
 lock=load(R/'rigor_runtime_lock.json');model_path=lock['snapshot_path']
 spec=importlib.util.spec_from_file_location('pinned_rigor_dynamic_app',R/'vendor/rigor/app.py');app=importlib.util.module_from_spec(spec);sys.modules[spec.name]=app;spec.loader.exec_module(app)
 app.SENT_MODEL=app.SentenceTransformer(model_path,device='cpu')
 current={};calls=[]
 class Client:
  def __init__(self,api_key,model):self.model=model
  def generate(self,prompt,temperature=.2,max_tokens=10000,retries=3):
   for retry in range(2):
    prior_call=getattr(transport.local,'last_call_dir',None)
    try:
     return transport([dict(role='user',content=prompt)],min(max_tokens,4096),system='You generate OWL 2 ontology fragments in Manchester Syntax. Return only valid Manchester Syntax and no explanation.',tag='rigordyn_'+str(current['run']))
    except BudgetExceeded:raise
    except Exception:
     if retry:raise
    finally:
     try:
      if transport.last_call_dir!=prior_call:calls.append(str(transport.last_call_dir))
     except AttributeError:pass
 app.OpenRouterLLM=Client;os.environ['OPENROUTER_API_KEY']='transport-injected-placeholder'
 root=Path('runtime/runs/rigor_burr_dynamic');root.mkdir(parents=True,exist_ok=True)
 new_plan=dict(method='RIGOR-Rebuild-with-fixed-seed/input-cache',official_source_sha256=digest(R/'vendor/rigor/app.py'),vendor_lock=load(R/'rigor_vendor_lock.json'),model=transport.model,run_ids=[17,29],api_seed=None,budget_shared_cap_usd=150,actual_rebuilds_planned=n*2,step_provenance_planned=64,contexts=plan,
  seed_policy='Every unique current input rebuilt from shared t0 O0, never previous prediction; sequence/run caches isolated',mapping_status='UNAVAILABLE: upstream emits ontology, no source mapping exporter fabricated',gold_visible=False,
  input_scope='Current schema PK/FK/column constraints and current documentation; official loader/retrieval retains upstream behavior. No row records/event/view adapter added.',O0_syntax='RDF/XML for official core.parse(format=xml); not OWL/XML')
 if (root/'plan.json').exists():
  assert a.resume,'Frozen baseline plan exists; specify --resume without overwriting'
  frozen=load(root/'plan.json')
  for field in ['contexts','official_source_sha256','vendor_lock','model','run_ids','actual_rebuilds_planned']:
   assert frozen[field]==new_plan[field],'Resume binding mismatch: '+field
  save(root/'execution_resume.json',dict(resumed_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),frozen_plan_sha256=digest(root/'plan.json'),runner_sha256=digest(Path(__file__)),policy='Skip both successful and failed recorded manifests; do not retry or overwrite',existing_manifests=len(list(root.glob('*/*/*/run_manifest.json')))))
 else:
  assert not a.resume,'Cannot resume without frozen plan'
  save(root/'plan.json',new_plan)
 stop=False;completed=0
 for run in [17,29]:
  current['run']=run;random.seed(run);app.np.random.seed(run)
  import torch
  torch.manual_seed(run)
  for seq in plan:
   for ctx in seq['contexts']:
    out=root/str(run)/seq['sequence_id']/ctx['context_sha256'][:12]
    recorded=[p.parent for p in out.parent.glob(out.name+'*/run_manifest.json')] if out.parent.exists() else []
    assert len(recorded)<=1,'Multiple recorded attempts require independent adjudication'
    if recorded:
     out=recorded[0]
     old=load(out/'run_manifest.json')
     assert old.get('context_sha256')==ctx['context_sha256'] and old.get('run_id')==run and old.get('sequence_id')==seq['sequence_id'],'Recorded context mismatch'
     assert old.get('hashes')==ctx['hashes'],'Recorded context input hashes mismatch'
     if old.get('status')=='PIPELINE_COMPLETED':assert (out/'ontology.owl').exists() and digest(out/'ontology.owl')==old['ontology_sha256'],'Recorded ontology missing/corrupt'
     completed+=1
     for t in ctx['times']:
      provenance_path=root/str(run)/seq['sequence_id']/f't{t}_provenance.json'
      if not provenance_path.exists():save(provenance_path,dict(run_id=run,sequence_id=seq['sequence_id'],t=t,status=old['status'],context_sha256=ctx['context_sha256'],current_input_hashes=ctx['hashes'],actual_run_manifest=str(out/'run_manifest.json'),actual_ontology=str(out/'ontology.owl') if old['status']=='PIPELINE_COMPLETED' else None,ontology_sha256=old.get('ontology_sha256'),cache_reused=t!=ctx['first_t'],cache_scope='same sequence and run; exact schema/docs/O0 hashes only',actual_rebuild_elapsed_s=old['elapsed_s'],incremental_cache_lookup_latency_s=None,action=None,mapping_status='UNAVAILABLE',semantic_effect_correct=None,provenance_reconstructed_on_resume=True))
     print(json.dumps(dict(run=run,sequence=seq['sequence_id'],times=ctx['times'],status='RESUME_SKIP_RECORDED_'+str(old.get('status')))),flush=True)
     continue
    if out.exists():
     # Interrupted unmanifested attempt is preserved, never overwritten or counted
     # as a completed run; a fresh sibling attempt records actual continuation.
     original=out;attempt=1
     while out.exists():out=original.with_name(original.name+'_resume'+str(attempt));attempt+=1
    out.mkdir(parents=True)
    obs=Path(ctx['observation']);schema=load(obs/'schema.json');save(out/'source_schema.json',schema);save(out/'schema_official.json',schema_for_official(schema))
    docs=out/'docs';docs.mkdir();(docs/'current_documentation.txt').write_text((obs/'documentation.json').read_text(encoding='utf-8'),encoding='utf-8')
    ext=out/'empty_external_ontologies';ext.mkdir();o0=out/'fixed_O0.owl';app.Graph().parse(ctx['o0'],format='turtle').serialize(o0,format='xml')
    record=dict(method='RIGOR-Rebuild-with-fixed-seed/input-cache',run_id=run,sequence_id=seq['sequence_id'],**ctx,
     fixed_seed_sha256=digest(o0),seed_rdf_triples=len(app.Graph().parse(o0,format='xml')),gold_visible=False,mapping_status='UNAVAILABLE',ontology_reasoner='NOT_RUN')
    calls.clear();start=time.perf_counter()
    try:
     with (out/'pipeline.log').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
      app.run_semantic_enrichment(schema_path=out/'schema_official.json',docs_path=docs,ontology_path=ext,core_owl_path=o0,output_path=out/'ontology.owl',direct_mappings_dir=out/'direct_mappings',model=transport.model,use_llm=True)
     graph=app.Graph().parse(out/'ontology.owl',format='xml');record.update(status='PIPELINE_COMPLETED',rdf_triples=len(graph),ontology_sha256=digest(out/'ontology.owl'))
    except Exception as ex:
     record.update(status='FAILED',error_type=type(ex).__name__)
     if isinstance(ex,BudgetExceeded):stop=True
    record.update(elapsed_s=time.perf_counter()-start,raw_api_call_paths=sorted(set(calls)))
    save(out/'run_manifest.json',record);completed+=1
    for t in ctx['times']:
     save(root/str(run)/seq['sequence_id']/f't{t}_provenance.json',dict(run_id=run,sequence_id=seq['sequence_id'],t=t,status=record['status'],context_sha256=ctx['context_sha256'],current_input_hashes=ctx['hashes'],actual_run_manifest=str(out/'run_manifest.json'),actual_ontology=str(out/'ontology.owl') if record['status']=='PIPELINE_COMPLETED' else None,ontology_sha256=record.get('ontology_sha256'),cache_reused=t!=ctx['first_t'],cache_scope='same sequence and run; exact schema/docs/O0 hashes only',actual_rebuild_elapsed_s=record['elapsed_s'],incremental_cache_lookup_latency_s=None,action=None,mapping_status='UNAVAILABLE',semantic_effect_correct=None))
    print(json.dumps(dict(run=run,sequence=seq['sequence_id'],times=ctx['times'],status=record['status'],elapsed_s=record['elapsed_s'],calls=len(record['raw_api_call_paths']))),flush=True)
    if stop:break
   if stop:break
  if stop:break
 save(root/'completion.json',dict(status='STOPPED_BUDGET' if stop else 'ALL_REBUILD_ATTEMPTS_RECORDED',attempted_unique_contexts=completed,planned_unique_contexts=n*2,complete=completed==n*2,formal_semantic_metrics=False))
if __name__=='__main__':main()
