"""Actual HermiT and failure-atomicity engineering demonstration, not model eval."""
import hashlib,json,sqlite3,sys
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'packages_minimal'),str(R/'evaluation')]
from rdflib import RDF
from ontoreason_core import Store,Event,Obligation,Assessor,file_sha
from reasoner_check import check
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path('runtime/local_dependency');out.mkdir(exist_ok=True)
db=out/'observations.sqlite'
if not db.exists():
    c=sqlite3.connect(db);c.executescript('CREATE TABLE Student(id INTEGER PRIMARY KEY);INSERT INTO Student VALUES(1);');c.close()
ontology='@prefix owl:<http://www.w3.org/2002/07/owl#>. <urn:Student> a owl:Class.'
mapping={'id':'student','query':'SELECT id FROM Student','heads':[[{'kind':'iri','template':'urn:student:{id}'},{'kind':'constant','value':str(RDF.type)},{'kind':'constant','value':'urn:Student'}]],'null_policy':'skip_statement','identity_policy':'source PK id'}
count=0
def actual_reasoner(graph):
    global count
    count+=1;p=out/f'actual_check_{count}';p.mkdir(exist_ok=True);ontology_path=p/'TBox_and_ABox.ttl';graph.serialize(ontology_path,format='turtle')
    result=check(ontology_path,p/'hermit');return result['ontology_consistent']
store=Store(out/'version_store')
assert store.head() is None,'Preserve existing demo; rerun only into a fresh directory'
parent=store.publish(None,ontology,{'student':mapping},db,{'selected':[]},{},{},actual_reasoner)
source=out/'authorized_business.txt';source.write_text('Engineering fixture: an authorized candidate is assessed independently.',encoding='utf-8')
ob=Obligation('business','fixture','Fixture assessment, not a real business judgement',((str(source),file_sha(source)),),'engineering-fixture','source PK')
assessor=Assessor({'fixture':lambda e,o:dict(status='SUPPORTED',reason='Controlled engine regression fixture only')},{k:'fixture-v1' for k in ['checker','compiler','model','prompt','search_scope']})
bad=Event('bad',set(),[ob],ontology_add='<urn:Student> <http://www.w3.org/2002/07/owl#disjointWith> <urn:Student>.')
rejected=False
try:store.publish(parent,ontology,{'student':mapping},db,{'selected':['bad']},{'bad':bad},{'bad':assessor.assess(bad)},actual_reasoner,assessor=assessor)
except ValueError:rejected=True
assert rejected and store.head()==parent
result={'scope':'controlled engineering fixtures; not accuracy or model superiority','actual_hermit_invocations':count,'positive_TBox_and_ABox_published':True,'self_disjoint_nonempty_class_rejected':True,'parent_HEAD_unchanged_after_failed_validation':True,'implementation_sha256':file_sha(R/'ontoreason_core.py')}
(out/'results.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result))

