"""Retrieve exact upstream archives. Review upstream rights before redistributing."""
from pathlib import Path
import hashlib,io,json,urllib.request,zipfile
R=Path(__file__).resolve().parent
def main():
 for name in ['burr','rigor']:
  lock=json.loads((R/(name+'_vendor_lock.json')).read_text(encoding='utf-8'))
  repo=lock['repo_url'].split('github.com/')[-1].strip('/')
  data=urllib.request.urlopen('https://codeload.github.com/'+repo+'/zip/'+lock['commit'],timeout=120).read()
  assert hashlib.sha256(data).hexdigest()==lock['archive_sha256'],'Upstream archive bytes changed; inspect before proceeding'
  root=(R/'vendor'/name).resolve();assert not root.exists(),'Use a fresh vendor folder'
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   for entry in z.infolist():
    rel=Path(*Path(entry.filename).parts[1:]);out=(root/rel).resolve()
    assert out.is_relative_to(root),'Unsafe archive path'
    if entry.is_dir():out.mkdir(parents=True,exist_ok=True)
    else:out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(entry))
  print(name,lock['commit'])
if __name__=='__main__':main()
