from pathlib import Path
import re,sqlite3,json,hashlib,importlib.util,time
R=Path(__file__).resolve().parent;S=R/'vendor/burr/real-world/iswc/real_world__iswc__original.sql';O=R/'data/iswc';O.mkdir(parents=True,exist_ok=True)
source=S.read_text(encoding='utf-8');clean=re.sub(r'^\s*--.*$','',source,flags=re.M)
creates=list(re.finditer(r'CREATE TABLE\s+(\w+)\s*\((.*?)\)\s*;',clean,re.S|re.I));assert len(creates)==9
fk={}
for match in re.finditer(r'ALTER TABLE\s+(\w+)\s+(.*?);',clean,re.S|re.I):
 for f in re.finditer(r'FOREIGN KEY\s*\(([^)]+)\)\s*REFERENCES\s+(\w+)\s*\(([^)]+)\)',match[2],re.I):fk.setdefault(match[1],[]).append((f[1],f[2],f[3]))
ddl=[]
for match in creates:
 body=match[2]
 for cols,table,refs in fk.get(match[1],[]):body+=f',\n FOREIGN KEY ({cols}) REFERENCES {table} ({refs})'
 ddl.append(f'CREATE TABLE {match[1]} ({body});')
db=O/'snapshot.sqlite'
if db.exists():raise SystemExit('Refusing to overwrite source snapshot; use a fresh run directory')
c=sqlite3.connect(db);c.executescript('\n'.join(ddl))
insert_count=0
# Read complete INSERT statements including quoted semicolons with sqlite's parser.
for match in re.finditer(r'\bINSERT INTO\b',clean,re.I):
 start=match.start();end=start
 while True:
  end=clean.find(';',end)+1
  if end==0:raise ValueError('unterminated INSERT')
  stmt=clean[start:end]
  if sqlite3.complete_statement(stmt):break
 c.executescript(stmt);insert_count+=1
c.commit();schema={};inventory=[]
for match in creates:
 table=match[1];cols=c.execute(f'PRAGMA table_info("{table}")').fetchall();fks=c.execute(f'PRAGMA foreign_key_list("{table}")').fetchall()
 schema[table]={'columns':{r[1]:r[2] for r in cols},'foreign_keys':[{'column':r[3],'references_table':r[2],'references_column':r[4]} for r in fks]}
 inventory.append(dict(table=table,columns=len(cols),foreign_keys=len(fks),rows=c.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0],primary_key=[r[1] for r in sorted(cols,key=lambda r:r[5]) if r[5]]))
violations=c.execute('PRAGMA foreign_key_check').fetchall();sql_dump='\n'.join(c.iterdump());c.close()
(O/'schema.sql').write_text('\n'.join(ddl),encoding='utf-8');(O/'snapshot.sql').write_text(sql_dump,encoding='utf-8');(O/'schema.json').write_text(json.dumps(schema,indent=2),encoding='utf-8')
report=dict(source_sha256=hashlib.sha256(S.read_bytes()).hexdigest(),tables=len(schema),columns=sum(x['columns'] for x in inventory),foreign_keys=sum(x['foreign_keys'] for x in inventory),inventory=inventory,insert_statements=insert_count,foreign_key_violations=violations,conversion='Only CREATE TABLE / INSERT and explicit ALTER FK parsed; psql/database destructive commands never executed; FK added inline; values/types and PK retained; SQLite engine differs from PostgreSQL')
(O/'conversion_manifest.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
spec=importlib.util.spec_from_file_location('rigor_direct_mapping',R/'vendor/rigor/mapping.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
start=time.perf_counter();owl=m.generate_manchester(schema,'http://example.org/iswc');elapsed=time.perf_counter()-start
(O/'rigor_direct_mapping_raw.omn').write_text(owl,encoding='utf-8')
# Mechanical source provenance adapter, independent of reference mappings.
parsed={t:m.parse_table(t,v) for t,v in schema.items()};pk={t:m.detect_primary_key(t,cols) for t,(cols,fks) in parsed.items()}
lines=['@prefix map: <http://example.org/iswc/mapping#> .','@prefix vocab: <http://example.org/iswc#> .','@prefix d2rq: <http://www.wiwiss.fu-berlin.de/suhl/bizer/D2RQ/0.1#> .']
for table,(cols,fks) in parsed.items():
 if not fks:fks=m.infer_foreign_keys(table,cols,set(parsed),pk)
 cls=m.to_class_name(table)
 lines.append(f'map:{table} a d2rq:ClassMap; d2rq:dataStorage map:database; d2rq:uriPattern "{table}/@@{table}.{pk[table]}@@"; d2rq:class vocab:{cls} .')
 for col,(ref,refcol) in fks.items():
  if m.is_self_referential(col,ref,table):continue
  lines.append(f'map:{table}_{col}_fk a d2rq:PropertyBridge; d2rq:belongsToClassMap map:{table}; d2rq:property vocab:has{m.to_class_name(ref)}; d2rq:refersToClassMap map:{ref}; d2rq:join "{table}.{col} = {ref}.{refcol}" .')
 for col in cols:
  if col==pk[table] or col in fks:continue
  lines.append(f'map:{table}_{col}_value a d2rq:PropertyBridge; d2rq:belongsToClassMap map:{table}; d2rq:property vocab:{col}; d2rq:column "{table}.{col}" .')
(O/'rigor_direct_mapping_provenance.ttl').write_text('\n'.join(lines),encoding='utf-8')
(O/'direct_mapping_run.json').write_text(json.dumps(dict(method='RIGOR-DirectMapping + mechanical D2RQ provenance adapter',model_calls=0,elapsed_s=elapsed,ontology_format='Manchester source; not reasoner validated',adapter_note='Uses official parse/PK/FK/ETL/self-reference rules without gold; composite PK reduced by official heuristic; exported source mapping is an adapter assumption, not upstream artifact'),indent=2),encoding='utf-8')
print(json.dumps(report))
