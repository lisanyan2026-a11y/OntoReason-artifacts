"""Offline checks of shared-seed retention; no model calls or test-label reads."""
import unittest
import tempfile,time,json
from pathlib import Path
from unittest.mock import patch
from rdflib import Graph,URIRef,Literal,RDFS
import run_core_shared_o0_v2 as runner


class SharedSeedTests(unittest.TestCase):
    def test_seed_comments_ranges_and_new_physical_ranges_preserved(self):
        seed=Graph()
        seed.add((URIRef('urn:p'),RDFS.range,URIRef('http://www.w3.org/2001/XMLSchema#integer')))
        seed.add((URIRef('urn:relation'),RDFS.comment,Literal('self reference')))
        with patch.object(runner.proposer,'turtle',return_value='<urn:C> a <http://www.w3.org/2002/07/owl#Class> .'),patch.object(runner,'datatype_map_for_state',return_value={'urn:p':'http://www.w3.org/2001/XMLSchema#integer','urn:new':'http://www.w3.org/2001/XMLSchema#string'}):
            graph=Graph().parse(data=runner.ontology_text({},'unused',seed),format='turtle')
        self.assertTrue(runner.seed_preservation(graph,seed)['all_seed_triples_retained'])
        self.assertIn((URIRef('urn:new'),RDFS.range,URIRef('http://www.w3.org/2001/XMLSchema#string')),graph)

    def test_changed_physical_range_cannot_silently_override_seed(self):
        seed=Graph()
        seed.add((URIRef('urn:p'),RDFS.range,URIRef('http://www.w3.org/2001/XMLSchema#integer')))
        with patch.object(runner.proposer,'turtle',return_value=''),patch.object(runner,'datatype_map_for_state',return_value={'urn:p':'http://www.w3.org/2001/XMLSchema#string'}):
            with self.assertRaisesRegex(ValueError,'Physical datatype conflicts'):
                runner.ontology_text({},'unused',seed)

    def test_missing_seed_triple_is_reported(self):
        seed=Graph().parse(data='<urn:p> <urn:annotation> "kept" .',format='turtle')
        report=runner.seed_preservation(Graph(),seed)
        self.assertFalse(report['all_seed_triples_retained'])
        self.assertEqual(report['retained_seed_triples'],0)

    def test_parallel_jobs_keep_each_rollout_order_and_directory_independent(self):
        base=Path('runtime/local_dependency')
        with tempfile.TemporaryDirectory(prefix='shared_jobs_',dir=base) as folder:
            root=Path(folder)
            def fake_rollout(seq,run,root,transport):
                destination=root/str(run)/seq
                destination.mkdir(parents=True)
                history=[]
                for t in range(1,5):
                    history.append(t)
                    time.sleep(.002)
                    (destination/f't{t}.json').write_text(json.dumps(dict(history=history,seed=seq)))
            with patch.object(runner,'rollout',side_effect=fake_rollout):
                runner.run_jobs(['a','b'],root,None,workers=2)
            for run in [17,29]:
                for seq in ['a','b']:
                    for t in range(1,5):
                        row=json.loads((root/str(run)/seq/f't{t}.json').read_text())
                        self.assertEqual(row['history'],list(range(1,t+1)))
                        self.assertEqual(row['seed'],seq)

    def test_preflight_rejects_modified_seed_before_execution(self):
        base=Path('runtime/local_dependency')
        with tempfile.TemporaryDirectory(prefix='seed_guard_',dir=base) as folder:
            shared=Path(folder);(shared/'a').mkdir();seed=shared/'a/O0.ttl';seed.write_text('<urn:a> <urn:b> <urn:c> .')
            (shared/'preflight.json').write_text(json.dumps(dict(all_pass=True,seed_sha256={'a':runner.file_sha(seed)})))
            with patch.object(runner,'SHARED',shared):
                runner.verify_preflight(['a'])
                seed.write_text('<urn:a> <urn:b> <urn:changed> .')
                with self.assertRaisesRegex(AssertionError,'Seed differs'):
                    runner.verify_preflight(['a'])


if __name__=='__main__':unittest.main(verbosity=2)
