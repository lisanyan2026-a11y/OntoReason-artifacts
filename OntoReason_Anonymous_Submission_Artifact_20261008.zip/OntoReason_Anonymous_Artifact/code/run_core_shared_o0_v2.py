"""Finite-fragment core-backed prototype, not the complete OntoReason paper system.
Current own state only; no gold/human annotations; main process supplies stdin token.
"""
import argparse,copy,hashlib,json,sys,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
R=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'packages_minimal'),str(R/'dynamic'),str(R/'evaluation')]
from rdflib import Graph
import model_adapted_framework_v3 as proposer
from shared_o0_contract import typed_inventory as inventory_from_state, datatype_map_for_state
from rdflib import URIRef,RDFS,Literal
from ontoreason_core import Store,Event,Obligation,Assessor,Registry,select,file_sha
from reasoner_check import check
VERSION='ontoreason-core-shared-o0-v2'
SHARED=Path('runtime/runs/shared_o0_v2')

def ontology_text(state,snapshot,seed_graph):
 graph=Graph().parse(data=proposer.turtle(state),format='turtle')
 for triple in seed_graph:graph.add(triple)
 for iri,dtype in datatype_map_for_state(state,snapshot).items():
  old=set(graph.objects(URIRef(iri),RDFS.range))
  if old and old!={URIRef(dtype)}:raise ValueError('Physical datatype conflicts with retained range: '+iri)
  graph.add((URIRef(iri),RDFS.range,URIRef(dtype)))
 return graph.serialize(format='turtle')

def seed_preservation(graph,seed_graph):
 return dict(seed_triples=len(seed_graph),retained_seed_triples=sum(triple in graph for triple in seed_graph),all_seed_triples_retained=all(triple in graph for triple in seed_graph))

def run_jobs(selected,root,transport,workers=2):
 jobs=[(seq,run) for run in [17,29] for seq in selected]
 with ThreadPoolExecutor(max_workers=workers) as pool:
  futures=[pool.submit(rollout,seq,run,root,transport) for seq,run in jobs]
  for future in futures:future.result()

def verify_preflight(selected):
 preflight=load(SHARED/'preflight.json')
 assert preflight.get('all_pass') is True,'Shared O0 preflight must pass before any API call'
 # The builder emits a sequence-indexed binding, independent of runtime inference.
 bindings=preflight['seed_sha256']
 for seq in selected:
  assert bindings[seq]==file_sha(SHARED/seq/'O0.ttl'),'Seed differs from preflight: '+seq
 return preflight

JUDGE='''Independently assess whether the candidate operations are the minimum justified ontology/mapping change under CURRENT source business evidence and accepted historical ontology. Check alternative reuse, aliases, unresolved conflicts, missing business interpretation, missing endpoint dependencies and omitted new business concepts. No proposal confidence is supplied. No-change must not ignore clearly new business meanings. Return JSON only: {"semantic":"SUPPORTED|REFUTED|UNKNOWN","alternatives_resolved":true,"actualsourcequotes":["verbatim CURRENT documentation quote"],"reason":"specific explanation"}. SUPPORTED requires actual verbatim business documentation supporting this exact candidate or complete no-change. Schema names or persistence alone do not establish independent business meaning. UNKNOWN if uncertain; never invent future evidence.'''
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
def parse_json(text):
 s=text.strip()
 if s.startswith('```'):s='\n'.join(s.splitlines()[1:-1])
 return json.loads(s)
def judge_status(result,documentation_text):
 if result.get('semantic') not in {'SUPPORTED','REFUTED','UNKNOWN'} or type(result.get('alternatives_resolved')) is not bool:return 'UNKNOWN'
 quotes=result.get('actualsourcequotes')
 if result['semantic']=='SUPPORTED' and (not result['alternatives_resolved'] or not isinstance(quotes,list) or not quotes or any(not isinstance(q,str) or not q.strip() or q not in documentation_text for q in quotes)):return 'UNKNOWN'
 return result['semantic']
def impact_trace(state,inventory,ob):
 consumers={};needs={}
 for table in ob['schema.json']:consumers['source:'+table]=set()
 for mid,mapping in inventory.items():
  unit='mapping:'+mid;source=mapping['source_provenance'];table=source['table'];consumers.setdefault('source:'+table,set()).add(unit)
  consumers[unit]=set();needs[unit]={'source:'+x for x in [source.get('source_table'),source.get('target_table')] if x}
 # Conservative whole registered source scope; no claim of minimal discovered region.
 registry=Registry(consumers,needs);seeds={k for k in consumers if k.startswith('source:')}
 region,trace=registry.refine(seeds,lambda _: 'UNKNOWN')
 return dict(registration={k:sorted(v) for k,v in consumers.items()},read_needs={k:sorted(v) for k,v in needs.items()},seeds=sorted(seeds),closure=sorted(region),refinement=trace,scope='conservative whole-source registered region, not full semantic impact discovery')
def rollout(seq,run,root,transport):
 source=R/'dynamic/dataset_candidate_v1/observed'/seq;out=root/str(run)/seq;out.mkdir(parents=True)
 store=Store(out/'store');initial,_=proposer.read_observation(source/'t0');state=proposer.initial_state(initial['schema.json']);state['relation_source_mappings']={k:dict(uri=v['uri'],kind='initial_direct_fk') for k,v in state['object_properties'].items()}
 seed_path=SHARED/seq/'O0.ttl';seed_sha=file_sha(seed_path);seed_graph=Graph().parse(seed_path,format='turtle')
 save(out/'shared_seed_binding.json',dict(path=str(seed_path),sha256=seed_sha,triples=len(seed_graph),provenance=load(SHARED/seq/'provenance.json')))
 reasoner_counter=[0];last_reasoner={}
 def actual_reasoner(graph):
  if any(isinstance(term,Literal) and getattr(term,'ill_typed',False) is True for triple in graph for term in triple):
   last_reasoner.clear();last_reasoner.update(status='UNKNOWN',ontology_consistent=None,error='Invalid physical datatype lexical value')
   return None
  reasoner_counter[0]+=1;folder=out/'reasoner'/str(reasoner_counter[0]);folder.mkdir(parents=True)
  path=folder/'ontology_and_materialized_facts.ttl';graph.serialize(path,format='turtle');result=check(path,folder)
  last_reasoner.clear();last_reasoner.update(result,audit_path=str(folder))
  return result['ontology_consistent']
 initial_inventory=inventory_from_state(state,source/'t0/snapshot.sqlite')
 try:head=store.publish(None,seed_path.read_text(encoding='utf-8'),initial_inventory,source/'t0/snapshot.sqlite',dict(selected=[]),{}, {},actual_reasoner)
 except Exception as ex:
  save(out/'initialization_failure.json',dict(error_type=type(ex).__name__,reasoner=last_reasoner))
  for t in range(1,5):save(out/f't{t}/decision.json',dict(method=VERSION,sequence_id=seq,run_id=run,t=t,action='FAILURE',stage='initialization',error_type=type(ex).__name__,semantic_effect_correct=None,rawcalls=[],joint_publication=False,reasoner=last_reasoner))
  return
 history=[initial];rows=[]
 for t in range(1,5):
  start=time.perf_counter();folder=out/f't{t}';folder.mkdir();ob,hashes=proposer.read_observation(source/f't{t}')
  parent=store.head();basepath=store.root/'versions'/parent['version'];ontology=(basepath/'ontology.ttl').read_text(encoding='utf-8');mappings=load(basepath/'mappings.json')
  record=dict(method=VERSION,sequence_id=seq,run_id=run,t=t,scope='finite-fragment core-backed prototype; one whole patch SCC, not multi-patch selective completeness',action='WAIT',semantic_effect_correct=None,visible_input_sha256=hashes,parent_version=parent['version'],api_seed=None,rawcalls=[],shared_o0_sha256=seed_sha,shared_o0_path=str(seed_path))
  candidate=None;proposal=None;judge={};assessment={};selection={};last_reasoner.clear()
  initial_raw_call=getattr(getattr(transport,'local',None),'last_call_dir',None)
  try:
   payload=dict(current_observation=ob,current_ontology=dict(classes=state['classes'],object_properties=state['object_properties']),source_mapping=proposer.source_mappings(state),past_observations=[dict(tables=sorted(x['schema.json']),documented_tables=sorted(x['documentation.json'].get('tables',{}))) for x in history])
   text=transport([dict(role='user',content=json.dumps(payload,ensure_ascii=False))],2048,system=proposer.SYSTEM,tag=f'core_proposer_{run}')
   record['rawcalls'].append(str(transport.last_call_dir));proposal=proposer.parse_proposal(dict(content=text));save(folder/'proposal.json',proposal)
   base=proposer.mechanical_reuse(state,ob);candidate,errors,_=proposer.validate_compile(base,ob,proposal)
   if errors:raise ValueError('Structural candidate rejected: '+','.join(errors))
   inventory=inventory_from_state(candidate,source/f't{t}/snapshot.sqlite');save(folder/'candidate_mappings.json',inventory)
   if set(mappings)-set(inventory):raise ValueError('Mapping deletion unsupported in bounded fragment')
   additions=Graph().parse(data=ontology_text(candidate,source/f't{t}/snapshot.sqlite',seed_graph),format='turtle')-Graph().parse(data=ontology,format='turtle')
   delta=additions.serialize(format='turtle') if len(additions) else ''
   updates={mid:value for mid,value in inventory.items() if mappings.get(mid)!=value}
   record['impact']=impact_trace(state,inventory,ob)
   judge_payload=dict(current_schema=ob['schema.json'],current_documentation=ob['documentation.json'],current_event=ob['event.json'],accepted_historical_ontology=ontology,candidate_operations=proposal['operations'],mechanical_mapping_repair=updates if not delta else None)
   response=transport([dict(role='user',content=json.dumps(judge_payload,ensure_ascii=False))],2048,system=JUDGE,tag=f'core_judge_{run}')
   judge_call=transport.last_call_dir;record['rawcalls'].append(str(judge_call));judge=parse_json(response);save(folder/'independent_judge.json',judge)
   docs_text=(source/f't{t}/documentation.json').read_text(encoding='utf-8');semantic=judge_status(judge,docs_text)
   sources=tuple((str((source/f't{t}'/n).resolve()),digest) for n,digest in hashes.items())+((str((source/f't{t}/snapshot.sqlite').resolve()),file_sha(source/f't{t}/snapshot.sqlite')),
     (str((judge_call/'response.json').resolve()),file_sha(judge_call/'response.json')))
   obligations=[Obligation('semantic','semantic','Exact candidate meaning, alternatives and omitted new business effects',sources,'independent separate judge with verbatim current documentation','actual-pk-v1'),Obligation('physical','physical','Current query/mapping realization and physical dependencies',sources,'SQLite schema, joins and records','actual-pk-v1')]
   def semantic_checker(event,obligation):return dict(status=semantic,reason=judge.get('reason',''),raw_judge_sha256=file_sha(judge_call/'response.json'))
   def physical_checker(event,obligation):
    try:matched=inventory_from_state(candidate,source/f't{t}/snapshot.sqlite')==inventory
    except Exception:return dict(status='REFUTED',reason='Independent physical realization failed')
    return dict(status='SUPPORTED' if matched else 'REFUTED',reason='Actual SQLite inventory reconstruction')
   assessor=Assessor(dict(semantic=semantic_checker,physical=physical_checker),dict(checker='source-quotes+SQLite-v1:'+file_sha(judge_call/'response.json'),compiler=VERSION,model=transport.model,prompt=hashlib.sha256(JUDGE.encode()).hexdigest(),search_scope='current_observed+own_accepted_history'))
   prefix=f'{seq}:{run}:{t}';alternatives=judge.get('alternatives_resolved') is True
   if delta:
    a=prefix+':ontology';b=prefix+':mapping';events={a:Event(a,{b},obligations,ontology_add=delta,alternatives_resolved=alternatives,interpretation='EVOLVE'),b:Event(b,{a},obligations,mapping_updates=updates,alternatives_resolved=alternatives,interpretation='EVOLVE')};interpretation='EVOLVE'
   else:
    name=prefix+':mapping' if updates else prefix+':reuse';interpretation='REPAIR' if updates else 'REUSE';events={name:Event(name,set(),obligations,mapping_updates=updates,alternatives_resolved=alternatives,interpretation=interpretation)}
   assessment={k:assessor.assess(e) for k,e in events.items()};selection=select(events,assessment,conflicts=(),historical=parent['accepted_events'])
   record.update(interpretation=interpretation,assessments=assessment,selection=selection,dependency_groups=selection['groups'],judge_semantic_status=semantic)
   if set(selection['selected'])!=set(events):raise ValueError('Unsupported/unknown obligations or unresolved alternatives; whole patch withheld')
   head=store.publish(parent,ontology,mappings,source/f't{t}/snapshot.sqlite',selection,events,assessment,actual_reasoner,conflicts=(),assessor=assessor)
   state=copy.deepcopy(candidate);record.update(action='EXTEND' if interpretation=='EVOLVE' else 'REUSE',published_version=head['version'],joint_publication=True)
  except Exception as ex:
   # No chosen patch is accepted until the authoritative store HEAD advances.
   record.update(error_type=type(ex).__name__,error=str(ex)[:240],joint_publication=False)
   try:
    call=str(transport.last_call_dir)
    if Path(call)!=initial_raw_call and call not in record['rawcalls'] and (Path(call)/'request.json').exists():record['rawcalls'].append(call)
   except AttributeError:pass
   if type(ex).__name__=='BudgetExceeded':record['action']='FAILURE'
  record.update(proposal=proposal,independent_judge=judge,reasoner=last_reasoner,elapsed_s=time.perf_counter()-start,retained_version=store.head()['version'])
  save(folder/'decision.json',record);rows.append(record);history.append(ob)
  retained=store.root/'versions'/store.head()['version'];(folder/'retained_ontology.ttl').write_text((retained/'ontology.ttl').read_text(encoding='utf-8'),encoding='utf-8');save(folder/'retained_mappings.json',load(retained/'mappings.json'));save(folder/'seed_preservation.json',dict(shared_o0_sha256=seed_sha,**seed_preservation(Graph().parse(retained/'ontology.ttl',format='turtle'),seed_graph)));save(folder/'retained_snapshot_binding.json',dict(snapshot=store.head()['snapshot'],sha256=store.head()['snapshot_sha256']))
  print(json.dumps(dict(sequence=seq,run=run,t=t,action=record['action'],publication=record['joint_publication'],elapsed_s=record['elapsed_s'])),flush=True)
 save(out/'rollout.json',rows)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--after-rigor',action='store_true');ap.add_argument('--parallel-authorized',action='store_true');a=ap.parse_args();token=sys.stdin.readline().strip()
 if not token:raise ValueError('stdin credential required')
 barrier=Path('runtime/runs/rigor_burr_dynamic/completion.json')
 if a.parallel_authorized:pass
 elif a.after_rigor:
  while not barrier.exists():print('Waiting for RIGOR shared-ledger completion',flush=True);time.sleep(30)
 else:assert barrier.exists(),'Wait for RIGOR or use parallel-authorized with cross-process budget lock'
 from anthropic_transport import Transport
 transport=Transport(token,R/'runs/api_calls',budget_limit=150);root=Path('runtime/runs/ontoreason_shared_v2');root.mkdir(parents=True,exist_ok=True);assert not (root/'plan.json').exists(),'Fresh run required'
 manifest=load(R/'dynamic/dataset_candidate_v1/manifest.json');selected=[m['sequence_id'] for m in manifest if m['split']=='test' and m['template_index']==4 and m['variant']==0]
 preflight=verify_preflight(selected)
 save(root/'preflight_binding.json',dict(path=str(SHARED/'preflight.json'),sha256=file_sha(SHARED/'preflight.json'),seed_sha256=preflight['seed_sha256'],workers=2))
 save(root/'plan.json',dict(method=VERSION,sequences=selected,run_ids=[17,29],planned_decisions=64,workers=2,model=transport.model,gold_visible=False,budget_shared_cap_usd=150,shared_o0_sha256={seq:file_sha(SHARED/seq/'O0.ttl') for seq in selected},source_sha256={n:file_sha(R/n) for n in ['run_core_shared_o0_v2.py','shared_o0_contract.py','ontoreason_core.py','ontoreason_mapping_bridge.py','dynamic/model_adapted_framework_v3.py']},limitations=['One whole-window patch SCC; no multiple-independent-patch selection','Conservative whole-source impact registration, not complete discovery','Separate LLM judge with exact quotes remains fallible; no human semantic approval','Bounded mapping fragment; unsupported physical structures block publication','NoAPIseed; one test source group; no GNN; not full paper system']))
 run_jobs(selected,root,transport,workers=2)
 save(root/'completion.json',dict(status='all64_attempts_recorded',planned_decisions=64,formal_semantic_metrics=False))
if __name__=='__main__':main()
