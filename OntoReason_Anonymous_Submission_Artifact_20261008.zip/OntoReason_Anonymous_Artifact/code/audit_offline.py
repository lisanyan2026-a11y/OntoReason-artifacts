"""No network, model, key, or source row data is used."""
from pathlib import Path
import collections,csv,json,hashlib,os
P=Path(__file__).resolve().parent.parent
if os.name=='nt' and not str(P).startswith(chr(92)*2):P=Path('\\\\?\\'+str(P))
def rows(rel):
 with (P/rel).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
 manifest=json.loads((P/'MANIFEST.json').read_text(encoding='utf-8'))
 for entry in manifest:
  file=P/entry['path'];assert hashlib.sha256(file.read_bytes()).hexdigest()==entry['sha256'],entry['path']
 candidates=rows('recorded/metrics/candidate_results.csv');assert len(candidates)==100
 assert collections.Counter(x['method'] for x in candidates)=={'OntoReason':50,'RIGOR':50}
 q=json.loads((P/'recorded/review/all_confirmed_subquestion_judgments.json').read_text(encoding='utf-8'))['answers'];assert len(q)==600
 decisions=[json.loads(f.read_text(encoding='utf-8')) for f in (P/'recorded/runs/ontoreason_shared_v2').glob('*/*/t*/decision.json')]
 assert len(decisions)==64
 actions=collections.Counter(x['action'] for x in decisions);assert actions=={'WAIT':44,'REUSE':15,'EXTEND':5}
 expected={'OntoReason':{'SUPPORTED_ON_APPLICABLE_ITEMS':37,'FAIL':6,'UNDETERMINED':7},'RIGOR':{'SUPPORTED_ON_APPLICABLE_ITEMS':15,'FAIL':9,'UNDETERMINED':26}}
 for method,counts in expected.items():assert collections.Counter(x['ontology_status'] for x in candidates if x['method']==method)==counts
 usage=rows('recorded/resources/api_usage.csv');summary=rows('recorded/resources/resource_summary.csv')
 assert sum(int(x['api_calls']) for x in summary)==659 and len(usage)==659
 print(json.dumps({'files_checked':len(manifest),'candidate_outputs':100,'review_subquestions':600,'decision_contexts':64,'actions':dict(actions),'api_rows':len(usage),'scope':'integrity and recorded-count audit; not independent semantic relabeling'},indent=2))
if __name__=='__main__':main()
